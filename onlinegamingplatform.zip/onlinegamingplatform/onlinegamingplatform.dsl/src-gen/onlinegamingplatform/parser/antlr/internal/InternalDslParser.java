package onlinegamingplatform.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import onlinegamingplatform.services.DslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'GamingPlatform'", "'{'", "'games'", "','", "'}'", "'-'", "'EDate'", "'MultiplayerGame'", "'title'", "'genre'", "'rating'", "'releaseDate'", "'maxPlayers'", "'TournamentGame'", "'tournamentFormat'", "'SinglePlayerGame'", "'difficultyLevels'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDsl.g"; }



     	private DslGrammarAccess grammarAccess;

        public InternalDslParser(TokenStream input, DslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "GamingPlatform";
       	}

       	@Override
       	protected DslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleGamingPlatform"
    // InternalDsl.g:64:1: entryRuleGamingPlatform returns [EObject current=null] : iv_ruleGamingPlatform= ruleGamingPlatform EOF ;
    public final EObject entryRuleGamingPlatform() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGamingPlatform = null;


        try {
            // InternalDsl.g:64:55: (iv_ruleGamingPlatform= ruleGamingPlatform EOF )
            // InternalDsl.g:65:2: iv_ruleGamingPlatform= ruleGamingPlatform EOF
            {
             newCompositeNode(grammarAccess.getGamingPlatformRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGamingPlatform=ruleGamingPlatform();

            state._fsp--;

             current =iv_ruleGamingPlatform; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGamingPlatform"


    // $ANTLR start "ruleGamingPlatform"
    // InternalDsl.g:71:1: ruleGamingPlatform returns [EObject current=null] : ( () otherlv_1= 'GamingPlatform' otherlv_2= '{' (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )? otherlv_9= '}' ) ;
    public final EObject ruleGamingPlatform() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        EObject lv_games_5_0 = null;

        EObject lv_games_7_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:77:2: ( ( () otherlv_1= 'GamingPlatform' otherlv_2= '{' (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )? otherlv_9= '}' ) )
            // InternalDsl.g:78:2: ( () otherlv_1= 'GamingPlatform' otherlv_2= '{' (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )? otherlv_9= '}' )
            {
            // InternalDsl.g:78:2: ( () otherlv_1= 'GamingPlatform' otherlv_2= '{' (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )? otherlv_9= '}' )
            // InternalDsl.g:79:3: () otherlv_1= 'GamingPlatform' otherlv_2= '{' (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )? otherlv_9= '}'
            {
            // InternalDsl.g:79:3: ()
            // InternalDsl.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getGamingPlatformAccess().getGamingPlatformAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getGamingPlatformAccess().getGamingPlatformKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:94:3: (otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalDsl.g:95:4: otherlv_3= 'games' otherlv_4= '{' ( (lv_games_5_0= ruleGame ) ) (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_3); 

                    				newLeafNode(otherlv_3, grammarAccess.getGamingPlatformAccess().getGamesKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,12,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_3_1());
                    			
                    // InternalDsl.g:103:4: ( (lv_games_5_0= ruleGame ) )
                    // InternalDsl.g:104:5: (lv_games_5_0= ruleGame )
                    {
                    // InternalDsl.g:104:5: (lv_games_5_0= ruleGame )
                    // InternalDsl.g:105:6: lv_games_5_0= ruleGame
                    {

                    						newCompositeNode(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_games_5_0=ruleGame();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGamingPlatformRule());
                    						}
                    						add(
                    							current,
                    							"games",
                    							lv_games_5_0,
                    							"onlinegamingplatform.Dsl.Game");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:122:4: (otherlv_6= ',' ( (lv_games_7_0= ruleGame ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalDsl.g:123:5: otherlv_6= ',' ( (lv_games_7_0= ruleGame ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_5); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getGamingPlatformAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalDsl.g:127:5: ( (lv_games_7_0= ruleGame ) )
                    	    // InternalDsl.g:128:6: (lv_games_7_0= ruleGame )
                    	    {
                    	    // InternalDsl.g:128:6: (lv_games_7_0= ruleGame )
                    	    // InternalDsl.g:129:7: lv_games_7_0= ruleGame
                    	    {

                    	    							newCompositeNode(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_games_7_0=ruleGame();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGamingPlatformRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"games",
                    	    								lv_games_7_0,
                    	    								"onlinegamingplatform.Dsl.Game");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_7); 

                    				newLeafNode(otherlv_8, grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_3_4());
                    			

                    }
                    break;

            }

            otherlv_9=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGamingPlatform"


    // $ANTLR start "entryRuleGame"
    // InternalDsl.g:160:1: entryRuleGame returns [EObject current=null] : iv_ruleGame= ruleGame EOF ;
    public final EObject entryRuleGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGame = null;


        try {
            // InternalDsl.g:160:45: (iv_ruleGame= ruleGame EOF )
            // InternalDsl.g:161:2: iv_ruleGame= ruleGame EOF
            {
             newCompositeNode(grammarAccess.getGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGame=ruleGame();

            state._fsp--;

             current =iv_ruleGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGame"


    // $ANTLR start "ruleGame"
    // InternalDsl.g:167:1: ruleGame returns [EObject current=null] : (this_MultiplayerGame_0= ruleMultiplayerGame | this_TournamentGame_1= ruleTournamentGame | this_SinglePlayerGame_2= ruleSinglePlayerGame ) ;
    public final EObject ruleGame() throws RecognitionException {
        EObject current = null;

        EObject this_MultiplayerGame_0 = null;

        EObject this_TournamentGame_1 = null;

        EObject this_SinglePlayerGame_2 = null;



        	enterRule();

        try {
            // InternalDsl.g:173:2: ( (this_MultiplayerGame_0= ruleMultiplayerGame | this_TournamentGame_1= ruleTournamentGame | this_SinglePlayerGame_2= ruleSinglePlayerGame ) )
            // InternalDsl.g:174:2: (this_MultiplayerGame_0= ruleMultiplayerGame | this_TournamentGame_1= ruleTournamentGame | this_SinglePlayerGame_2= ruleSinglePlayerGame )
            {
            // InternalDsl.g:174:2: (this_MultiplayerGame_0= ruleMultiplayerGame | this_TournamentGame_1= ruleTournamentGame | this_SinglePlayerGame_2= ruleSinglePlayerGame )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt3=1;
                }
                break;
            case 24:
                {
                alt3=2;
                }
                break;
            case 26:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalDsl.g:175:3: this_MultiplayerGame_0= ruleMultiplayerGame
                    {

                    			newCompositeNode(grammarAccess.getGameAccess().getMultiplayerGameParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_MultiplayerGame_0=ruleMultiplayerGame();

                    state._fsp--;


                    			current = this_MultiplayerGame_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalDsl.g:184:3: this_TournamentGame_1= ruleTournamentGame
                    {

                    			newCompositeNode(grammarAccess.getGameAccess().getTournamentGameParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_TournamentGame_1=ruleTournamentGame();

                    state._fsp--;


                    			current = this_TournamentGame_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalDsl.g:193:3: this_SinglePlayerGame_2= ruleSinglePlayerGame
                    {

                    			newCompositeNode(grammarAccess.getGameAccess().getSinglePlayerGameParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_SinglePlayerGame_2=ruleSinglePlayerGame();

                    state._fsp--;


                    			current = this_SinglePlayerGame_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGame"


    // $ANTLR start "entryRuleEString"
    // InternalDsl.g:205:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalDsl.g:205:47: (iv_ruleEString= ruleEString EOF )
            // InternalDsl.g:206:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalDsl.g:212:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalDsl.g:218:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalDsl.g:219:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalDsl.g:219:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_STRING) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_ID) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalDsl.g:220:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalDsl.g:228:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleEInt"
    // InternalDsl.g:239:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalDsl.g:239:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalDsl.g:240:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalDsl.g:246:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalDsl.g:252:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalDsl.g:253:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalDsl.g:253:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalDsl.g:254:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalDsl.g:254:3: (kw= '-' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalDsl.g:255:4: kw= '-'
                    {
                    kw=(Token)match(input,16,FOLLOW_8); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEDate"
    // InternalDsl.g:272:1: entryRuleEDate returns [String current=null] : iv_ruleEDate= ruleEDate EOF ;
    public final String entryRuleEDate() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEDate = null;


        try {
            // InternalDsl.g:272:45: (iv_ruleEDate= ruleEDate EOF )
            // InternalDsl.g:273:2: iv_ruleEDate= ruleEDate EOF
            {
             newCompositeNode(grammarAccess.getEDateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEDate=ruleEDate();

            state._fsp--;

             current =iv_ruleEDate.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEDate"


    // $ANTLR start "ruleEDate"
    // InternalDsl.g:279:1: ruleEDate returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'EDate' ;
    public final AntlrDatatypeRuleToken ruleEDate() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDsl.g:285:2: (kw= 'EDate' )
            // InternalDsl.g:286:2: kw= 'EDate'
            {
            kw=(Token)match(input,17,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getEDateAccess().getEDateKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEDate"


    // $ANTLR start "entryRuleMultiplayerGame"
    // InternalDsl.g:294:1: entryRuleMultiplayerGame returns [EObject current=null] : iv_ruleMultiplayerGame= ruleMultiplayerGame EOF ;
    public final EObject entryRuleMultiplayerGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMultiplayerGame = null;


        try {
            // InternalDsl.g:294:56: (iv_ruleMultiplayerGame= ruleMultiplayerGame EOF )
            // InternalDsl.g:295:2: iv_ruleMultiplayerGame= ruleMultiplayerGame EOF
            {
             newCompositeNode(grammarAccess.getMultiplayerGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMultiplayerGame=ruleMultiplayerGame();

            state._fsp--;

             current =iv_ruleMultiplayerGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMultiplayerGame"


    // $ANTLR start "ruleMultiplayerGame"
    // InternalDsl.g:301:1: ruleMultiplayerGame returns [EObject current=null] : ( () otherlv_1= 'MultiplayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )? otherlv_13= '}' ) ;
    public final EObject ruleMultiplayerGame() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_title_4_0 = null;

        AntlrDatatypeRuleToken lv_genre_6_0 = null;

        AntlrDatatypeRuleToken lv_rating_8_0 = null;

        AntlrDatatypeRuleToken lv_releaseDate_10_0 = null;

        AntlrDatatypeRuleToken lv_maxPlayers_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:307:2: ( ( () otherlv_1= 'MultiplayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )? otherlv_13= '}' ) )
            // InternalDsl.g:308:2: ( () otherlv_1= 'MultiplayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            {
            // InternalDsl.g:308:2: ( () otherlv_1= 'MultiplayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            // InternalDsl.g:309:3: () otherlv_1= 'MultiplayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )? otherlv_13= '}'
            {
            // InternalDsl.g:309:3: ()
            // InternalDsl.g:310:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMultiplayerGameAccess().getMultiplayerGameAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getMultiplayerGameAccess().getMultiplayerGameKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_9); 

            			newLeafNode(otherlv_2, grammarAccess.getMultiplayerGameAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:324:3: (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==19) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalDsl.g:325:4: otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,19,FOLLOW_10); 

                    				newLeafNode(otherlv_3, grammarAccess.getMultiplayerGameAccess().getTitleKeyword_3_0());
                    			
                    // InternalDsl.g:329:4: ( (lv_title_4_0= ruleEString ) )
                    // InternalDsl.g:330:5: (lv_title_4_0= ruleEString )
                    {
                    // InternalDsl.g:330:5: (lv_title_4_0= ruleEString )
                    // InternalDsl.g:331:6: lv_title_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMultiplayerGameAccess().getTitleEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_title_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMultiplayerGameRule());
                    						}
                    						set(
                    							current,
                    							"title",
                    							lv_title_4_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:349:3: (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalDsl.g:350:4: otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,20,FOLLOW_10); 

                    				newLeafNode(otherlv_5, grammarAccess.getMultiplayerGameAccess().getGenreKeyword_4_0());
                    			
                    // InternalDsl.g:354:4: ( (lv_genre_6_0= ruleEString ) )
                    // InternalDsl.g:355:5: (lv_genre_6_0= ruleEString )
                    {
                    // InternalDsl.g:355:5: (lv_genre_6_0= ruleEString )
                    // InternalDsl.g:356:6: lv_genre_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMultiplayerGameAccess().getGenreEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_genre_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMultiplayerGameRule());
                    						}
                    						set(
                    							current,
                    							"genre",
                    							lv_genre_6_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:374:3: (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalDsl.g:375:4: otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) )
                    {
                    otherlv_7=(Token)match(input,21,FOLLOW_13); 

                    				newLeafNode(otherlv_7, grammarAccess.getMultiplayerGameAccess().getRatingKeyword_5_0());
                    			
                    // InternalDsl.g:379:4: ( (lv_rating_8_0= ruleEInt ) )
                    // InternalDsl.g:380:5: (lv_rating_8_0= ruleEInt )
                    {
                    // InternalDsl.g:380:5: (lv_rating_8_0= ruleEInt )
                    // InternalDsl.g:381:6: lv_rating_8_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMultiplayerGameAccess().getRatingEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_rating_8_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMultiplayerGameRule());
                    						}
                    						set(
                    							current,
                    							"rating",
                    							lv_rating_8_0,
                    							"onlinegamingplatform.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:399:3: (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDsl.g:400:4: otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) )
                    {
                    otherlv_9=(Token)match(input,22,FOLLOW_15); 

                    				newLeafNode(otherlv_9, grammarAccess.getMultiplayerGameAccess().getReleaseDateKeyword_6_0());
                    			
                    // InternalDsl.g:404:4: ( (lv_releaseDate_10_0= ruleEDate ) )
                    // InternalDsl.g:405:5: (lv_releaseDate_10_0= ruleEDate )
                    {
                    // InternalDsl.g:405:5: (lv_releaseDate_10_0= ruleEDate )
                    // InternalDsl.g:406:6: lv_releaseDate_10_0= ruleEDate
                    {

                    						newCompositeNode(grammarAccess.getMultiplayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_releaseDate_10_0=ruleEDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMultiplayerGameRule());
                    						}
                    						set(
                    							current,
                    							"releaseDate",
                    							lv_releaseDate_10_0,
                    							"onlinegamingplatform.Dsl.EDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:424:3: (otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==23) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalDsl.g:425:4: otherlv_11= 'maxPlayers' ( (lv_maxPlayers_12_0= ruleEInt ) )
                    {
                    otherlv_11=(Token)match(input,23,FOLLOW_13); 

                    				newLeafNode(otherlv_11, grammarAccess.getMultiplayerGameAccess().getMaxPlayersKeyword_7_0());
                    			
                    // InternalDsl.g:429:4: ( (lv_maxPlayers_12_0= ruleEInt ) )
                    // InternalDsl.g:430:5: (lv_maxPlayers_12_0= ruleEInt )
                    {
                    // InternalDsl.g:430:5: (lv_maxPlayers_12_0= ruleEInt )
                    // InternalDsl.g:431:6: lv_maxPlayers_12_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMultiplayerGameAccess().getMaxPlayersEIntParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_maxPlayers_12_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMultiplayerGameRule());
                    						}
                    						set(
                    							current,
                    							"maxPlayers",
                    							lv_maxPlayers_12_0,
                    							"onlinegamingplatform.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_13=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getMultiplayerGameAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplayerGame"


    // $ANTLR start "entryRuleTournamentGame"
    // InternalDsl.g:457:1: entryRuleTournamentGame returns [EObject current=null] : iv_ruleTournamentGame= ruleTournamentGame EOF ;
    public final EObject entryRuleTournamentGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTournamentGame = null;


        try {
            // InternalDsl.g:457:55: (iv_ruleTournamentGame= ruleTournamentGame EOF )
            // InternalDsl.g:458:2: iv_ruleTournamentGame= ruleTournamentGame EOF
            {
             newCompositeNode(grammarAccess.getTournamentGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTournamentGame=ruleTournamentGame();

            state._fsp--;

             current =iv_ruleTournamentGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTournamentGame"


    // $ANTLR start "ruleTournamentGame"
    // InternalDsl.g:464:1: ruleTournamentGame returns [EObject current=null] : ( () otherlv_1= 'TournamentGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )? otherlv_13= '}' ) ;
    public final EObject ruleTournamentGame() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_title_4_0 = null;

        AntlrDatatypeRuleToken lv_genre_6_0 = null;

        AntlrDatatypeRuleToken lv_rating_8_0 = null;

        AntlrDatatypeRuleToken lv_releaseDate_10_0 = null;

        AntlrDatatypeRuleToken lv_tournamentFormat_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:470:2: ( ( () otherlv_1= 'TournamentGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )? otherlv_13= '}' ) )
            // InternalDsl.g:471:2: ( () otherlv_1= 'TournamentGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )? otherlv_13= '}' )
            {
            // InternalDsl.g:471:2: ( () otherlv_1= 'TournamentGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )? otherlv_13= '}' )
            // InternalDsl.g:472:3: () otherlv_1= 'TournamentGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )? otherlv_13= '}'
            {
            // InternalDsl.g:472:3: ()
            // InternalDsl.g:473:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTournamentGameAccess().getTournamentGameAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,24,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getTournamentGameAccess().getTournamentGameKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getTournamentGameAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:487:3: (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==19) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalDsl.g:488:4: otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,19,FOLLOW_10); 

                    				newLeafNode(otherlv_3, grammarAccess.getTournamentGameAccess().getTitleKeyword_3_0());
                    			
                    // InternalDsl.g:492:4: ( (lv_title_4_0= ruleEString ) )
                    // InternalDsl.g:493:5: (lv_title_4_0= ruleEString )
                    {
                    // InternalDsl.g:493:5: (lv_title_4_0= ruleEString )
                    // InternalDsl.g:494:6: lv_title_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getTournamentGameAccess().getTitleEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_title_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTournamentGameRule());
                    						}
                    						set(
                    							current,
                    							"title",
                    							lv_title_4_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:512:3: (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==20) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalDsl.g:513:4: otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,20,FOLLOW_10); 

                    				newLeafNode(otherlv_5, grammarAccess.getTournamentGameAccess().getGenreKeyword_4_0());
                    			
                    // InternalDsl.g:517:4: ( (lv_genre_6_0= ruleEString ) )
                    // InternalDsl.g:518:5: (lv_genre_6_0= ruleEString )
                    {
                    // InternalDsl.g:518:5: (lv_genre_6_0= ruleEString )
                    // InternalDsl.g:519:6: lv_genre_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getTournamentGameAccess().getGenreEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_genre_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTournamentGameRule());
                    						}
                    						set(
                    							current,
                    							"genre",
                    							lv_genre_6_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:537:3: (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==21) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalDsl.g:538:4: otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) )
                    {
                    otherlv_7=(Token)match(input,21,FOLLOW_13); 

                    				newLeafNode(otherlv_7, grammarAccess.getTournamentGameAccess().getRatingKeyword_5_0());
                    			
                    // InternalDsl.g:542:4: ( (lv_rating_8_0= ruleEInt ) )
                    // InternalDsl.g:543:5: (lv_rating_8_0= ruleEInt )
                    {
                    // InternalDsl.g:543:5: (lv_rating_8_0= ruleEInt )
                    // InternalDsl.g:544:6: lv_rating_8_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getTournamentGameAccess().getRatingEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_rating_8_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTournamentGameRule());
                    						}
                    						set(
                    							current,
                    							"rating",
                    							lv_rating_8_0,
                    							"onlinegamingplatform.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:562:3: (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==22) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalDsl.g:563:4: otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) )
                    {
                    otherlv_9=(Token)match(input,22,FOLLOW_15); 

                    				newLeafNode(otherlv_9, grammarAccess.getTournamentGameAccess().getReleaseDateKeyword_6_0());
                    			
                    // InternalDsl.g:567:4: ( (lv_releaseDate_10_0= ruleEDate ) )
                    // InternalDsl.g:568:5: (lv_releaseDate_10_0= ruleEDate )
                    {
                    // InternalDsl.g:568:5: (lv_releaseDate_10_0= ruleEDate )
                    // InternalDsl.g:569:6: lv_releaseDate_10_0= ruleEDate
                    {

                    						newCompositeNode(grammarAccess.getTournamentGameAccess().getReleaseDateEDateParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_21);
                    lv_releaseDate_10_0=ruleEDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTournamentGameRule());
                    						}
                    						set(
                    							current,
                    							"releaseDate",
                    							lv_releaseDate_10_0,
                    							"onlinegamingplatform.Dsl.EDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:587:3: (otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==25) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalDsl.g:588:4: otherlv_11= 'tournamentFormat' ( (lv_tournamentFormat_12_0= ruleEString ) )
                    {
                    otherlv_11=(Token)match(input,25,FOLLOW_10); 

                    				newLeafNode(otherlv_11, grammarAccess.getTournamentGameAccess().getTournamentFormatKeyword_7_0());
                    			
                    // InternalDsl.g:592:4: ( (lv_tournamentFormat_12_0= ruleEString ) )
                    // InternalDsl.g:593:5: (lv_tournamentFormat_12_0= ruleEString )
                    {
                    // InternalDsl.g:593:5: (lv_tournamentFormat_12_0= ruleEString )
                    // InternalDsl.g:594:6: lv_tournamentFormat_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getTournamentGameAccess().getTournamentFormatEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_tournamentFormat_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTournamentGameRule());
                    						}
                    						set(
                    							current,
                    							"tournamentFormat",
                    							lv_tournamentFormat_12_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_13=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getTournamentGameAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTournamentGame"


    // $ANTLR start "entryRuleSinglePlayerGame"
    // InternalDsl.g:620:1: entryRuleSinglePlayerGame returns [EObject current=null] : iv_ruleSinglePlayerGame= ruleSinglePlayerGame EOF ;
    public final EObject entryRuleSinglePlayerGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSinglePlayerGame = null;


        try {
            // InternalDsl.g:620:57: (iv_ruleSinglePlayerGame= ruleSinglePlayerGame EOF )
            // InternalDsl.g:621:2: iv_ruleSinglePlayerGame= ruleSinglePlayerGame EOF
            {
             newCompositeNode(grammarAccess.getSinglePlayerGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSinglePlayerGame=ruleSinglePlayerGame();

            state._fsp--;

             current =iv_ruleSinglePlayerGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSinglePlayerGame"


    // $ANTLR start "ruleSinglePlayerGame"
    // InternalDsl.g:627:1: ruleSinglePlayerGame returns [EObject current=null] : ( () otherlv_1= 'SinglePlayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )? otherlv_13= '}' ) ;
    public final EObject ruleSinglePlayerGame() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_title_4_0 = null;

        AntlrDatatypeRuleToken lv_genre_6_0 = null;

        AntlrDatatypeRuleToken lv_rating_8_0 = null;

        AntlrDatatypeRuleToken lv_releaseDate_10_0 = null;

        AntlrDatatypeRuleToken lv_difficultyLevels_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:633:2: ( ( () otherlv_1= 'SinglePlayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )? otherlv_13= '}' ) )
            // InternalDsl.g:634:2: ( () otherlv_1= 'SinglePlayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            {
            // InternalDsl.g:634:2: ( () otherlv_1= 'SinglePlayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            // InternalDsl.g:635:3: () otherlv_1= 'SinglePlayerGame' otherlv_2= '{' (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )? (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )? (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )? (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )? (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )? otherlv_13= '}'
            {
            // InternalDsl.g:635:3: ()
            // InternalDsl.g:636:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,26,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_22); 

            			newLeafNode(otherlv_2, grammarAccess.getSinglePlayerGameAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:650:3: (otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==19) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalDsl.g:651:4: otherlv_3= 'title' ( (lv_title_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,19,FOLLOW_10); 

                    				newLeafNode(otherlv_3, grammarAccess.getSinglePlayerGameAccess().getTitleKeyword_3_0());
                    			
                    // InternalDsl.g:655:4: ( (lv_title_4_0= ruleEString ) )
                    // InternalDsl.g:656:5: (lv_title_4_0= ruleEString )
                    {
                    // InternalDsl.g:656:5: (lv_title_4_0= ruleEString )
                    // InternalDsl.g:657:6: lv_title_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSinglePlayerGameAccess().getTitleEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_title_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSinglePlayerGameRule());
                    						}
                    						set(
                    							current,
                    							"title",
                    							lv_title_4_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:675:3: (otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==20) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalDsl.g:676:4: otherlv_5= 'genre' ( (lv_genre_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,20,FOLLOW_10); 

                    				newLeafNode(otherlv_5, grammarAccess.getSinglePlayerGameAccess().getGenreKeyword_4_0());
                    			
                    // InternalDsl.g:680:4: ( (lv_genre_6_0= ruleEString ) )
                    // InternalDsl.g:681:5: (lv_genre_6_0= ruleEString )
                    {
                    // InternalDsl.g:681:5: (lv_genre_6_0= ruleEString )
                    // InternalDsl.g:682:6: lv_genre_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSinglePlayerGameAccess().getGenreEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_24);
                    lv_genre_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSinglePlayerGameRule());
                    						}
                    						set(
                    							current,
                    							"genre",
                    							lv_genre_6_0,
                    							"onlinegamingplatform.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:700:3: (otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==21) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalDsl.g:701:4: otherlv_7= 'rating' ( (lv_rating_8_0= ruleEInt ) )
                    {
                    otherlv_7=(Token)match(input,21,FOLLOW_13); 

                    				newLeafNode(otherlv_7, grammarAccess.getSinglePlayerGameAccess().getRatingKeyword_5_0());
                    			
                    // InternalDsl.g:705:4: ( (lv_rating_8_0= ruleEInt ) )
                    // InternalDsl.g:706:5: (lv_rating_8_0= ruleEInt )
                    {
                    // InternalDsl.g:706:5: (lv_rating_8_0= ruleEInt )
                    // InternalDsl.g:707:6: lv_rating_8_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSinglePlayerGameAccess().getRatingEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_25);
                    lv_rating_8_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSinglePlayerGameRule());
                    						}
                    						set(
                    							current,
                    							"rating",
                    							lv_rating_8_0,
                    							"onlinegamingplatform.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:725:3: (otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==22) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalDsl.g:726:4: otherlv_9= 'releaseDate' ( (lv_releaseDate_10_0= ruleEDate ) )
                    {
                    otherlv_9=(Token)match(input,22,FOLLOW_15); 

                    				newLeafNode(otherlv_9, grammarAccess.getSinglePlayerGameAccess().getReleaseDateKeyword_6_0());
                    			
                    // InternalDsl.g:730:4: ( (lv_releaseDate_10_0= ruleEDate ) )
                    // InternalDsl.g:731:5: (lv_releaseDate_10_0= ruleEDate )
                    {
                    // InternalDsl.g:731:5: (lv_releaseDate_10_0= ruleEDate )
                    // InternalDsl.g:732:6: lv_releaseDate_10_0= ruleEDate
                    {

                    						newCompositeNode(grammarAccess.getSinglePlayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_26);
                    lv_releaseDate_10_0=ruleEDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSinglePlayerGameRule());
                    						}
                    						set(
                    							current,
                    							"releaseDate",
                    							lv_releaseDate_10_0,
                    							"onlinegamingplatform.Dsl.EDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:750:3: (otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==27) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalDsl.g:751:4: otherlv_11= 'difficultyLevels' ( (lv_difficultyLevels_12_0= ruleEInt ) )
                    {
                    otherlv_11=(Token)match(input,27,FOLLOW_13); 

                    				newLeafNode(otherlv_11, grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsKeyword_7_0());
                    			
                    // InternalDsl.g:755:4: ( (lv_difficultyLevels_12_0= ruleEInt ) )
                    // InternalDsl.g:756:5: (lv_difficultyLevels_12_0= ruleEInt )
                    {
                    // InternalDsl.g:756:5: (lv_difficultyLevels_12_0= ruleEInt )
                    // InternalDsl.g:757:6: lv_difficultyLevels_12_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsEIntParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_difficultyLevels_12_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSinglePlayerGameRule());
                    						}
                    						set(
                    							current,
                    							"difficultyLevels",
                    							lv_difficultyLevels_12_0,
                    							"onlinegamingplatform.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_13=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getSinglePlayerGameAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSinglePlayerGame"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000000A000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000005040000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000F88000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000F08000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000E08000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000010040L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000C08000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000808000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000002788000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002708000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000002608000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000002408000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000002008000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000008788000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000008708000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000008608000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000008408000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000008008000L});

}