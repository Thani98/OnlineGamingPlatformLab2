/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformFactory
 * @model kind="package"
 * @generated
 */
public interface OnlinegamingplatformPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "onlinegamingplatform";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/onlinegamingplatform";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "onlinegamingplatform";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	OnlinegamingplatformPackage eINSTANCE = onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl
			.init();

	/**
	 * The meta object id for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GamingPlatformImpl <em>Gaming Platform</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.GamingPlatformImpl
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getGamingPlatform()
	 * @generated
	 */
	int GAMING_PLATFORM = 0;

	/**
	 * The feature id for the '<em><b>Games</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAMING_PLATFORM__GAMES = 0;

	/**
	 * The number of structural features of the '<em>Gaming Platform</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAMING_PLATFORM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Gaming Platform</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAMING_PLATFORM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl <em>Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getGame()
	 * @generated
	 */
	int GAME = 1;

	/**
	 * The feature id for the '<em><b>Multiplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__MULTIPLAYERGAME = 0;

	/**
	 * The feature id for the '<em><b>Singleplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__SINGLEPLAYERGAME = 1;

	/**
	 * The feature id for the '<em><b>Tournamentgame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__TOURNAMENTGAME = 2;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__TITLE = 3;

	/**
	 * The feature id for the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__GENRE = 4;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__RATING = 5;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__RELEASE_DATE = 6;

	/**
	 * The number of structural features of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.MultiplayerGameImpl <em>Multiplayer Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.MultiplayerGameImpl
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getMultiplayerGame()
	 * @generated
	 */
	int MULTIPLAYER_GAME = 2;

	/**
	 * The feature id for the '<em><b>Multiplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__MULTIPLAYERGAME = GAME__MULTIPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Singleplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__SINGLEPLAYERGAME = GAME__SINGLEPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Tournamentgame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__TOURNAMENTGAME = GAME__TOURNAMENTGAME;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__TITLE = GAME__TITLE;

	/**
	 * The feature id for the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__GENRE = GAME__GENRE;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__RATING = GAME__RATING;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__RELEASE_DATE = GAME__RELEASE_DATE;

	/**
	 * The feature id for the '<em><b>Max Players</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME__MAX_PLAYERS = GAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Multiplayer Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME_FEATURE_COUNT = GAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Multiplayer Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLAYER_GAME_OPERATION_COUNT = GAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.TournamentGameImpl <em>Tournament Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.TournamentGameImpl
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getTournamentGame()
	 * @generated
	 */
	int TOURNAMENT_GAME = 3;

	/**
	 * The feature id for the '<em><b>Multiplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__MULTIPLAYERGAME = GAME__MULTIPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Singleplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__SINGLEPLAYERGAME = GAME__SINGLEPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Tournamentgame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__TOURNAMENTGAME = GAME__TOURNAMENTGAME;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__TITLE = GAME__TITLE;

	/**
	 * The feature id for the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__GENRE = GAME__GENRE;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__RATING = GAME__RATING;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__RELEASE_DATE = GAME__RELEASE_DATE;

	/**
	 * The feature id for the '<em><b>Tournament Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME__TOURNAMENT_FORMAT = GAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Tournament Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME_FEATURE_COUNT = GAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Tournament Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOURNAMENT_GAME_OPERATION_COUNT = GAME_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.SinglePlayerGameImpl <em>Single Player Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.SinglePlayerGameImpl
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getSinglePlayerGame()
	 * @generated
	 */
	int SINGLE_PLAYER_GAME = 4;

	/**
	 * The feature id for the '<em><b>Multiplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__MULTIPLAYERGAME = GAME__MULTIPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Singleplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__SINGLEPLAYERGAME = GAME__SINGLEPLAYERGAME;

	/**
	 * The feature id for the '<em><b>Tournamentgame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__TOURNAMENTGAME = GAME__TOURNAMENTGAME;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__TITLE = GAME__TITLE;

	/**
	 * The feature id for the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__GENRE = GAME__GENRE;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__RATING = GAME__RATING;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__RELEASE_DATE = GAME__RELEASE_DATE;

	/**
	 * The feature id for the '<em><b>Difficulty Levels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS = GAME_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Single Player Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME_FEATURE_COUNT = GAME_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Single Player Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINGLE_PLAYER_GAME_OPERATION_COUNT = GAME_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform <em>Gaming Platform</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Gaming Platform</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform
	 * @generated
	 */
	EClass getGamingPlatform();

	/**
	 * Returns the meta object for the containment reference list '{@link onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform#getGames <em>Games</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Games</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform#getGames()
	 * @see #getGamingPlatform()
	 * @generated
	 */
	EReference getGamingPlatform_Games();

	/**
	 * Returns the meta object for class '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game
	 * @generated
	 */
	EClass getGame();

	/**
	 * Returns the meta object for the reference '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getMultiplayergame <em>Multiplayergame</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Multiplayergame</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getMultiplayergame()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_Multiplayergame();

	/**
	 * Returns the meta object for the reference '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getSingleplayergame <em>Singleplayergame</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Singleplayergame</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getSingleplayergame()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_Singleplayergame();

	/**
	 * Returns the meta object for the reference '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTournamentgame <em>Tournamentgame</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Tournamentgame</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTournamentgame()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_Tournamentgame();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTitle()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Title();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getGenre <em>Genre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Genre</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getGenre()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Genre();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getRating <em>Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rating</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getRating()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Rating();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getReleaseDate <em>Release Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release Date</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.Game#getReleaseDate()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_ReleaseDate();

	/**
	 * Returns the meta object for class '{@link onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame <em>Multiplayer Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Multiplayer Game</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame
	 * @generated
	 */
	EClass getMultiplayerGame();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame#getMaxPlayers <em>Max Players</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Players</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame#getMaxPlayers()
	 * @see #getMultiplayerGame()
	 * @generated
	 */
	EAttribute getMultiplayerGame_MaxPlayers();

	/**
	 * Returns the meta object for class '{@link onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame <em>Tournament Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tournament Game</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame
	 * @generated
	 */
	EClass getTournamentGame();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame#getTournamentFormat <em>Tournament Format</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tournament Format</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame#getTournamentFormat()
	 * @see #getTournamentGame()
	 * @generated
	 */
	EAttribute getTournamentGame_TournamentFormat();

	/**
	 * Returns the meta object for class '{@link onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame <em>Single Player Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Single Player Game</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame
	 * @generated
	 */
	EClass getSinglePlayerGame();

	/**
	 * Returns the meta object for the attribute '{@link onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame#getDifficultyLevels <em>Difficulty Levels</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Difficulty Levels</em>'.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame#getDifficultyLevels()
	 * @see #getSinglePlayerGame()
	 * @generated
	 */
	EAttribute getSinglePlayerGame_DifficultyLevels();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	OnlinegamingplatformFactory getOnlinegamingplatformFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GamingPlatformImpl <em>Gaming Platform</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.GamingPlatformImpl
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getGamingPlatform()
		 * @generated
		 */
		EClass GAMING_PLATFORM = eINSTANCE.getGamingPlatform();

		/**
		 * The meta object literal for the '<em><b>Games</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAMING_PLATFORM__GAMES = eINSTANCE.getGamingPlatform_Games();

		/**
		 * The meta object literal for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl <em>Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getGame()
		 * @generated
		 */
		EClass GAME = eINSTANCE.getGame();

		/**
		 * The meta object literal for the '<em><b>Multiplayergame</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__MULTIPLAYERGAME = eINSTANCE.getGame_Multiplayergame();

		/**
		 * The meta object literal for the '<em><b>Singleplayergame</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__SINGLEPLAYERGAME = eINSTANCE.getGame_Singleplayergame();

		/**
		 * The meta object literal for the '<em><b>Tournamentgame</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__TOURNAMENTGAME = eINSTANCE.getGame_Tournamentgame();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__TITLE = eINSTANCE.getGame_Title();

		/**
		 * The meta object literal for the '<em><b>Genre</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__GENRE = eINSTANCE.getGame_Genre();

		/**
		 * The meta object literal for the '<em><b>Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__RATING = eINSTANCE.getGame_Rating();

		/**
		 * The meta object literal for the '<em><b>Release Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__RELEASE_DATE = eINSTANCE.getGame_ReleaseDate();

		/**
		 * The meta object literal for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.MultiplayerGameImpl <em>Multiplayer Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.MultiplayerGameImpl
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getMultiplayerGame()
		 * @generated
		 */
		EClass MULTIPLAYER_GAME = eINSTANCE.getMultiplayerGame();

		/**
		 * The meta object literal for the '<em><b>Max Players</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MULTIPLAYER_GAME__MAX_PLAYERS = eINSTANCE.getMultiplayerGame_MaxPlayers();

		/**
		 * The meta object literal for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.TournamentGameImpl <em>Tournament Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.TournamentGameImpl
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getTournamentGame()
		 * @generated
		 */
		EClass TOURNAMENT_GAME = eINSTANCE.getTournamentGame();

		/**
		 * The meta object literal for the '<em><b>Tournament Format</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOURNAMENT_GAME__TOURNAMENT_FORMAT = eINSTANCE.getTournamentGame_TournamentFormat();

		/**
		 * The meta object literal for the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.SinglePlayerGameImpl <em>Single Player Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.SinglePlayerGameImpl
		 * @see onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformPackageImpl#getSinglePlayerGame()
		 * @generated
		 */
		EClass SINGLE_PLAYER_GAME = eINSTANCE.getSinglePlayerGame();

		/**
		 * The meta object literal for the '<em><b>Difficulty Levels</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS = eINSTANCE.getSinglePlayerGame_DifficultyLevels();

	}

} //OnlinegamingplatformPackage
