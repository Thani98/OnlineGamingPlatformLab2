/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiplayer Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame#getMaxPlayers <em>Max Players</em>}</li>
 * </ul>
 *
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getMultiplayerGame()
 * @model
 * @generated
 */
public interface MultiplayerGame extends Game {
	/**
	 * Returns the value of the '<em><b>Max Players</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Players</em>' attribute.
	 * @see #setMaxPlayers(int)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getMultiplayerGame_MaxPlayers()
	 * @model
	 * @generated
	 */
	int getMaxPlayers();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame#getMaxPlayers <em>Max Players</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Players</em>' attribute.
	 * @see #getMaxPlayers()
	 * @generated
	 */
	void setMaxPlayers(int value);

} // MultiplayerGame
