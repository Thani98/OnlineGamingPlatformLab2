/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tournament Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame#getTournamentFormat <em>Tournament Format</em>}</li>
 * </ul>
 *
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getTournamentGame()
 * @model
 * @generated
 */
public interface TournamentGame extends Game {
	/**
	 * Returns the value of the '<em><b>Tournament Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tournament Format</em>' attribute.
	 * @see #setTournamentFormat(String)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getTournamentGame_TournamentFormat()
	 * @model
	 * @generated
	 */
	String getTournamentFormat();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame#getTournamentFormat <em>Tournament Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tournament Format</em>' attribute.
	 * @see #getTournamentFormat()
	 * @generated
	 */
	void setTournamentFormat(String value);

} // TournamentGame
