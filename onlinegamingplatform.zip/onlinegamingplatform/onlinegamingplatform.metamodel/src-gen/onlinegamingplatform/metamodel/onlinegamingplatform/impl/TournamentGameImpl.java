/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage;
import onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tournament Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.TournamentGameImpl#getTournamentFormat <em>Tournament Format</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TournamentGameImpl extends GameImpl implements TournamentGame {
	/**
	 * The default value of the '{@link #getTournamentFormat() <em>Tournament Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTournamentFormat()
	 * @generated
	 * @ordered
	 */
	protected static final String TOURNAMENT_FORMAT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTournamentFormat() <em>Tournament Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTournamentFormat()
	 * @generated
	 * @ordered
	 */
	protected String tournamentFormat = TOURNAMENT_FORMAT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TournamentGameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OnlinegamingplatformPackage.Literals.TOURNAMENT_GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTournamentFormat() {
		return tournamentFormat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTournamentFormat(String newTournamentFormat) {
		String oldTournamentFormat = tournamentFormat;
		tournamentFormat = newTournamentFormat;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					OnlinegamingplatformPackage.TOURNAMENT_GAME__TOURNAMENT_FORMAT, oldTournamentFormat,
					tournamentFormat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OnlinegamingplatformPackage.TOURNAMENT_GAME__TOURNAMENT_FORMAT:
			return getTournamentFormat();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OnlinegamingplatformPackage.TOURNAMENT_GAME__TOURNAMENT_FORMAT:
			setTournamentFormat((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.TOURNAMENT_GAME__TOURNAMENT_FORMAT:
			setTournamentFormat(TOURNAMENT_FORMAT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.TOURNAMENT_GAME__TOURNAMENT_FORMAT:
			return TOURNAMENT_FORMAT_EDEFAULT == null ? tournamentFormat != null
					: !TOURNAMENT_FORMAT_EDEFAULT.equals(tournamentFormat);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (tournamentFormat: ");
		result.append(tournamentFormat);
		result.append(')');
		return result.toString();
	}

} //TournamentGameImpl
