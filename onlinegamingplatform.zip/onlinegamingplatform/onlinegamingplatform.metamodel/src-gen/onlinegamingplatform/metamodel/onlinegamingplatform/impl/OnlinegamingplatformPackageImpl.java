/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import onlinegamingplatform.metamodel.onlinegamingplatform.Game;
import onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform;
import onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame;
import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformFactory;
import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage;
import onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame;
import onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class OnlinegamingplatformPackageImpl extends EPackageImpl implements OnlinegamingplatformPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gamingPlatformEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass multiplayerGameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tournamentGameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass singlePlayerGameEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private OnlinegamingplatformPackageImpl() {
		super(eNS_URI, OnlinegamingplatformFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link OnlinegamingplatformPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static OnlinegamingplatformPackage init() {
		if (isInited)
			return (OnlinegamingplatformPackage) EPackage.Registry.INSTANCE
					.getEPackage(OnlinegamingplatformPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredOnlinegamingplatformPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		OnlinegamingplatformPackageImpl theOnlinegamingplatformPackage = registeredOnlinegamingplatformPackage instanceof OnlinegamingplatformPackageImpl
				? (OnlinegamingplatformPackageImpl) registeredOnlinegamingplatformPackage
				: new OnlinegamingplatformPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theOnlinegamingplatformPackage.createPackageContents();

		// Initialize created meta-data
		theOnlinegamingplatformPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theOnlinegamingplatformPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(OnlinegamingplatformPackage.eNS_URI, theOnlinegamingplatformPackage);
		return theOnlinegamingplatformPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGamingPlatform() {
		return gamingPlatformEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGamingPlatform_Games() {
		return (EReference) gamingPlatformEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGame() {
		return gameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGame_Multiplayergame() {
		return (EReference) gameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGame_Singleplayergame() {
		return (EReference) gameEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getGame_Tournamentgame() {
		return (EReference) gameEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGame_Title() {
		return (EAttribute) gameEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGame_Genre() {
		return (EAttribute) gameEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGame_Rating() {
		return (EAttribute) gameEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGame_ReleaseDate() {
		return (EAttribute) gameEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMultiplayerGame() {
		return multiplayerGameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMultiplayerGame_MaxPlayers() {
		return (EAttribute) multiplayerGameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTournamentGame() {
		return tournamentGameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTournamentGame_TournamentFormat() {
		return (EAttribute) tournamentGameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSinglePlayerGame() {
		return singlePlayerGameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSinglePlayerGame_DifficultyLevels() {
		return (EAttribute) singlePlayerGameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OnlinegamingplatformFactory getOnlinegamingplatformFactory() {
		return (OnlinegamingplatformFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		gamingPlatformEClass = createEClass(GAMING_PLATFORM);
		createEReference(gamingPlatformEClass, GAMING_PLATFORM__GAMES);

		gameEClass = createEClass(GAME);
		createEReference(gameEClass, GAME__MULTIPLAYERGAME);
		createEReference(gameEClass, GAME__SINGLEPLAYERGAME);
		createEReference(gameEClass, GAME__TOURNAMENTGAME);
		createEAttribute(gameEClass, GAME__TITLE);
		createEAttribute(gameEClass, GAME__GENRE);
		createEAttribute(gameEClass, GAME__RATING);
		createEAttribute(gameEClass, GAME__RELEASE_DATE);

		multiplayerGameEClass = createEClass(MULTIPLAYER_GAME);
		createEAttribute(multiplayerGameEClass, MULTIPLAYER_GAME__MAX_PLAYERS);

		tournamentGameEClass = createEClass(TOURNAMENT_GAME);
		createEAttribute(tournamentGameEClass, TOURNAMENT_GAME__TOURNAMENT_FORMAT);

		singlePlayerGameEClass = createEClass(SINGLE_PLAYER_GAME);
		createEAttribute(singlePlayerGameEClass, SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		multiplayerGameEClass.getESuperTypes().add(this.getGame());
		tournamentGameEClass.getESuperTypes().add(this.getGame());
		singlePlayerGameEClass.getESuperTypes().add(this.getGame());

		// Initialize classes, features, and operations; add parameters
		initEClass(gamingPlatformEClass, GamingPlatform.class, "GamingPlatform", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGamingPlatform_Games(), this.getGame(), null, "games", null, 0, -1, GamingPlatform.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(gameEClass, Game.class, "Game", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGame_Multiplayergame(), this.getMultiplayerGame(), null, "multiplayergame", null, 0, 1,
				Game.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getGame_Singleplayergame(), this.getSinglePlayerGame(), null, "singleplayergame", null, 0, 1,
				Game.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getGame_Tournamentgame(), this.getTournamentGame(), null, "tournamentgame", null, 0, 1,
				Game.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEAttribute(getGame_Title(), ecorePackage.getEString(), "title", null, 0, 1, Game.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGame_Genre(), ecorePackage.getEString(), "genre", null, 0, 1, Game.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGame_Rating(), ecorePackage.getEInt(), "rating", null, 0, 1, Game.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGame_ReleaseDate(), ecorePackage.getEDate(), "releaseDate", null, 0, 1, Game.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(multiplayerGameEClass, MultiplayerGame.class, "MultiplayerGame", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMultiplayerGame_MaxPlayers(), ecorePackage.getEInt(), "maxPlayers", null, 0, 1,
				MultiplayerGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(tournamentGameEClass, TournamentGame.class, "TournamentGame", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTournamentGame_TournamentFormat(), ecorePackage.getEString(), "tournamentFormat", null, 0, 1,
				TournamentGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(singlePlayerGameEClass, SinglePlayerGame.class, "SinglePlayerGame", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSinglePlayerGame_DifficultyLevels(), ecorePackage.getEInt(), "difficultyLevels", null, 0, 1,
				SinglePlayerGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //OnlinegamingplatformPackageImpl
