/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import java.util.Date;

import onlinegamingplatform.metamodel.onlinegamingplatform.Game;
import onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame;
import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage;
import onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame;
import onlinegamingplatform.metamodel.onlinegamingplatform.TournamentGame;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getMultiplayergame <em>Multiplayergame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getSingleplayergame <em>Singleplayergame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getTournamentgame <em>Tournamentgame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getTitle <em>Title</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getGenre <em>Genre</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getRating <em>Rating</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.GameImpl#getReleaseDate <em>Release Date</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class GameImpl extends MinimalEObjectImpl.Container implements Game {
	/**
	 * The cached value of the '{@link #getMultiplayergame() <em>Multiplayergame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMultiplayergame()
	 * @generated
	 * @ordered
	 */
	protected MultiplayerGame multiplayergame;

	/**
	 * The cached value of the '{@link #getSingleplayergame() <em>Singleplayergame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSingleplayergame()
	 * @generated
	 * @ordered
	 */
	protected SinglePlayerGame singleplayergame;

	/**
	 * The cached value of the '{@link #getTournamentgame() <em>Tournamentgame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTournamentgame()
	 * @generated
	 * @ordered
	 */
	protected TournamentGame tournamentgame;

	/**
	 * The default value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected static final String TITLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTitle() <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTitle()
	 * @generated
	 * @ordered
	 */
	protected String title = TITLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getGenre() <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenre()
	 * @generated
	 * @ordered
	 */
	protected static final String GENRE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGenre() <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenre()
	 * @generated
	 * @ordered
	 */
	protected String genre = GENRE_EDEFAULT;

	/**
	 * The default value of the '{@link #getRating() <em>Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRating()
	 * @generated
	 * @ordered
	 */
	protected static final int RATING_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getRating() <em>Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRating()
	 * @generated
	 * @ordered
	 */
	protected int rating = RATING_EDEFAULT;

	/**
	 * The default value of the '{@link #getReleaseDate() <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReleaseDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date RELEASE_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReleaseDate() <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReleaseDate()
	 * @generated
	 * @ordered
	 */
	protected Date releaseDate = RELEASE_DATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OnlinegamingplatformPackage.Literals.GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MultiplayerGame getMultiplayergame() {
		if (multiplayergame != null && multiplayergame.eIsProxy()) {
			InternalEObject oldMultiplayergame = (InternalEObject) multiplayergame;
			multiplayergame = (MultiplayerGame) eResolveProxy(oldMultiplayergame);
			if (multiplayergame != oldMultiplayergame) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME, oldMultiplayergame, multiplayergame));
			}
		}
		return multiplayergame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MultiplayerGame basicGetMultiplayergame() {
		return multiplayergame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMultiplayergame(MultiplayerGame newMultiplayergame) {
		MultiplayerGame oldMultiplayergame = multiplayergame;
		multiplayergame = newMultiplayergame;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME,
					oldMultiplayergame, multiplayergame));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SinglePlayerGame getSingleplayergame() {
		if (singleplayergame != null && singleplayergame.eIsProxy()) {
			InternalEObject oldSingleplayergame = (InternalEObject) singleplayergame;
			singleplayergame = (SinglePlayerGame) eResolveProxy(oldSingleplayergame);
			if (singleplayergame != oldSingleplayergame) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME, oldSingleplayergame, singleplayergame));
			}
		}
		return singleplayergame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SinglePlayerGame basicGetSingleplayergame() {
		return singleplayergame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSingleplayergame(SinglePlayerGame newSingleplayergame) {
		SinglePlayerGame oldSingleplayergame = singleplayergame;
		singleplayergame = newSingleplayergame;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME,
					oldSingleplayergame, singleplayergame));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TournamentGame getTournamentgame() {
		if (tournamentgame != null && tournamentgame.eIsProxy()) {
			InternalEObject oldTournamentgame = (InternalEObject) tournamentgame;
			tournamentgame = (TournamentGame) eResolveProxy(oldTournamentgame);
			if (tournamentgame != oldTournamentgame) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							OnlinegamingplatformPackage.GAME__TOURNAMENTGAME, oldTournamentgame, tournamentgame));
			}
		}
		return tournamentgame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TournamentGame basicGetTournamentgame() {
		return tournamentgame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTournamentgame(TournamentGame newTournamentgame) {
		TournamentGame oldTournamentgame = tournamentgame;
		tournamentgame = newTournamentgame;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__TOURNAMENTGAME,
					oldTournamentgame, tournamentgame));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTitle(String newTitle) {
		String oldTitle = title;
		title = newTitle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__TITLE, oldTitle,
					title));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGenre(String newGenre) {
		String oldGenre = genre;
		genre = newGenre;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__GENRE, oldGenre,
					genre));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRating(int newRating) {
		int oldRating = rating;
		rating = newRating;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__RATING, oldRating,
					rating));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getReleaseDate() {
		return releaseDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseDate(Date newReleaseDate) {
		Date oldReleaseDate = releaseDate;
		releaseDate = newReleaseDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, OnlinegamingplatformPackage.GAME__RELEASE_DATE,
					oldReleaseDate, releaseDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME:
			if (resolve)
				return getMultiplayergame();
			return basicGetMultiplayergame();
		case OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME:
			if (resolve)
				return getSingleplayergame();
			return basicGetSingleplayergame();
		case OnlinegamingplatformPackage.GAME__TOURNAMENTGAME:
			if (resolve)
				return getTournamentgame();
			return basicGetTournamentgame();
		case OnlinegamingplatformPackage.GAME__TITLE:
			return getTitle();
		case OnlinegamingplatformPackage.GAME__GENRE:
			return getGenre();
		case OnlinegamingplatformPackage.GAME__RATING:
			return getRating();
		case OnlinegamingplatformPackage.GAME__RELEASE_DATE:
			return getReleaseDate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME:
			setMultiplayergame((MultiplayerGame) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME:
			setSingleplayergame((SinglePlayerGame) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__TOURNAMENTGAME:
			setTournamentgame((TournamentGame) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__TITLE:
			setTitle((String) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__GENRE:
			setGenre((String) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__RATING:
			setRating((Integer) newValue);
			return;
		case OnlinegamingplatformPackage.GAME__RELEASE_DATE:
			setReleaseDate((Date) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME:
			setMultiplayergame((MultiplayerGame) null);
			return;
		case OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME:
			setSingleplayergame((SinglePlayerGame) null);
			return;
		case OnlinegamingplatformPackage.GAME__TOURNAMENTGAME:
			setTournamentgame((TournamentGame) null);
			return;
		case OnlinegamingplatformPackage.GAME__TITLE:
			setTitle(TITLE_EDEFAULT);
			return;
		case OnlinegamingplatformPackage.GAME__GENRE:
			setGenre(GENRE_EDEFAULT);
			return;
		case OnlinegamingplatformPackage.GAME__RATING:
			setRating(RATING_EDEFAULT);
			return;
		case OnlinegamingplatformPackage.GAME__RELEASE_DATE:
			setReleaseDate(RELEASE_DATE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.GAME__MULTIPLAYERGAME:
			return multiplayergame != null;
		case OnlinegamingplatformPackage.GAME__SINGLEPLAYERGAME:
			return singleplayergame != null;
		case OnlinegamingplatformPackage.GAME__TOURNAMENTGAME:
			return tournamentgame != null;
		case OnlinegamingplatformPackage.GAME__TITLE:
			return TITLE_EDEFAULT == null ? title != null : !TITLE_EDEFAULT.equals(title);
		case OnlinegamingplatformPackage.GAME__GENRE:
			return GENRE_EDEFAULT == null ? genre != null : !GENRE_EDEFAULT.equals(genre);
		case OnlinegamingplatformPackage.GAME__RATING:
			return rating != RATING_EDEFAULT;
		case OnlinegamingplatformPackage.GAME__RELEASE_DATE:
			return RELEASE_DATE_EDEFAULT == null ? releaseDate != null : !RELEASE_DATE_EDEFAULT.equals(releaseDate);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (title: ");
		result.append(title);
		result.append(", genre: ");
		result.append(genre);
		result.append(", rating: ");
		result.append(rating);
		result.append(", releaseDate: ");
		result.append(releaseDate);
		result.append(')');
		return result.toString();
	}

} //GameImpl
