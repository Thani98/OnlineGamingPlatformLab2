/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import onlinegamingplatform.metamodel.onlinegamingplatform.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class OnlinegamingplatformFactoryImpl extends EFactoryImpl implements OnlinegamingplatformFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static OnlinegamingplatformFactory init() {
		try {
			OnlinegamingplatformFactory theOnlinegamingplatformFactory = (OnlinegamingplatformFactory) EPackage.Registry.INSTANCE
					.getEFactory(OnlinegamingplatformPackage.eNS_URI);
			if (theOnlinegamingplatformFactory != null) {
				return theOnlinegamingplatformFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new OnlinegamingplatformFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OnlinegamingplatformFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case OnlinegamingplatformPackage.GAMING_PLATFORM:
			return createGamingPlatform();
		case OnlinegamingplatformPackage.MULTIPLAYER_GAME:
			return createMultiplayerGame();
		case OnlinegamingplatformPackage.TOURNAMENT_GAME:
			return createTournamentGame();
		case OnlinegamingplatformPackage.SINGLE_PLAYER_GAME:
			return createSinglePlayerGame();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GamingPlatform createGamingPlatform() {
		GamingPlatformImpl gamingPlatform = new GamingPlatformImpl();
		return gamingPlatform;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MultiplayerGame createMultiplayerGame() {
		MultiplayerGameImpl multiplayerGame = new MultiplayerGameImpl();
		return multiplayerGame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TournamentGame createTournamentGame() {
		TournamentGameImpl tournamentGame = new TournamentGameImpl();
		return tournamentGame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SinglePlayerGame createSinglePlayerGame() {
		SinglePlayerGameImpl singlePlayerGame = new SinglePlayerGameImpl();
		return singlePlayerGame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OnlinegamingplatformPackage getOnlinegamingplatformPackage() {
		return (OnlinegamingplatformPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static OnlinegamingplatformPackage getPackage() {
		return OnlinegamingplatformPackage.eINSTANCE;
	}

} //OnlinegamingplatformFactoryImpl
