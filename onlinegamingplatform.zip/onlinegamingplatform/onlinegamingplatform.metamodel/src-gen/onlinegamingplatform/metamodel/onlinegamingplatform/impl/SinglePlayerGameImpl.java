/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage;
import onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Single Player Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.SinglePlayerGameImpl#getDifficultyLevels <em>Difficulty Levels</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SinglePlayerGameImpl extends GameImpl implements SinglePlayerGame {
	/**
	 * The default value of the '{@link #getDifficultyLevels() <em>Difficulty Levels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDifficultyLevels()
	 * @generated
	 * @ordered
	 */
	protected static final int DIFFICULTY_LEVELS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDifficultyLevels() <em>Difficulty Levels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDifficultyLevels()
	 * @generated
	 * @ordered
	 */
	protected int difficultyLevels = DIFFICULTY_LEVELS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SinglePlayerGameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OnlinegamingplatformPackage.Literals.SINGLE_PLAYER_GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDifficultyLevels() {
		return difficultyLevels;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDifficultyLevels(int newDifficultyLevels) {
		int oldDifficultyLevels = difficultyLevels;
		difficultyLevels = newDifficultyLevels;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					OnlinegamingplatformPackage.SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS, oldDifficultyLevels,
					difficultyLevels));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OnlinegamingplatformPackage.SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS:
			return getDifficultyLevels();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OnlinegamingplatformPackage.SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS:
			setDifficultyLevels((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS:
			setDifficultyLevels(DIFFICULTY_LEVELS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.SINGLE_PLAYER_GAME__DIFFICULTY_LEVELS:
			return difficultyLevels != DIFFICULTY_LEVELS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (difficultyLevels: ");
		result.append(difficultyLevels);
		result.append(')');
		return result.toString();
	}

} //SinglePlayerGameImpl
