/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform.impl;

import onlinegamingplatform.metamodel.onlinegamingplatform.MultiplayerGame;
import onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Multiplayer Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.impl.MultiplayerGameImpl#getMaxPlayers <em>Max Players</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MultiplayerGameImpl extends GameImpl implements MultiplayerGame {
	/**
	 * The default value of the '{@link #getMaxPlayers() <em>Max Players</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxPlayers()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_PLAYERS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getMaxPlayers() <em>Max Players</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxPlayers()
	 * @generated
	 * @ordered
	 */
	protected int maxPlayers = MAX_PLAYERS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MultiplayerGameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return OnlinegamingplatformPackage.Literals.MULTIPLAYER_GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxPlayers() {
		return maxPlayers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxPlayers(int newMaxPlayers) {
		int oldMaxPlayers = maxPlayers;
		maxPlayers = newMaxPlayers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					OnlinegamingplatformPackage.MULTIPLAYER_GAME__MAX_PLAYERS, oldMaxPlayers, maxPlayers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case OnlinegamingplatformPackage.MULTIPLAYER_GAME__MAX_PLAYERS:
			return getMaxPlayers();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case OnlinegamingplatformPackage.MULTIPLAYER_GAME__MAX_PLAYERS:
			setMaxPlayers((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.MULTIPLAYER_GAME__MAX_PLAYERS:
			setMaxPlayers(MAX_PLAYERS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case OnlinegamingplatformPackage.MULTIPLAYER_GAME__MAX_PLAYERS:
			return maxPlayers != MAX_PLAYERS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (maxPlayers: ");
		result.append(maxPlayers);
		result.append(')');
		return result.toString();
	}

} //MultiplayerGameImpl
