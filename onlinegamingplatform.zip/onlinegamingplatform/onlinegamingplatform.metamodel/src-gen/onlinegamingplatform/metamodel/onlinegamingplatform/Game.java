/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

import java.util.Date;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getMultiplayergame <em>Multiplayergame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getSingleplayergame <em>Singleplayergame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTournamentgame <em>Tournamentgame</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTitle <em>Title</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getGenre <em>Genre</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getRating <em>Rating</em>}</li>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getReleaseDate <em>Release Date</em>}</li>
 * </ul>
 *
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame()
 * @model abstract="true"
 * @generated
 */
public interface Game extends EObject {
	/**
	 * Returns the value of the '<em><b>Multiplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multiplayergame</em>' reference.
	 * @see #setMultiplayergame(MultiplayerGame)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Multiplayergame()
	 * @model derived="true"
	 * @generated
	 */
	MultiplayerGame getMultiplayergame();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getMultiplayergame <em>Multiplayergame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multiplayergame</em>' reference.
	 * @see #getMultiplayergame()
	 * @generated
	 */
	void setMultiplayergame(MultiplayerGame value);

	/**
	 * Returns the value of the '<em><b>Singleplayergame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Singleplayergame</em>' reference.
	 * @see #setSingleplayergame(SinglePlayerGame)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Singleplayergame()
	 * @model derived="true"
	 * @generated
	 */
	SinglePlayerGame getSingleplayergame();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getSingleplayergame <em>Singleplayergame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Singleplayergame</em>' reference.
	 * @see #getSingleplayergame()
	 * @generated
	 */
	void setSingleplayergame(SinglePlayerGame value);

	/**
	 * Returns the value of the '<em><b>Tournamentgame</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tournamentgame</em>' reference.
	 * @see #setTournamentgame(TournamentGame)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Tournamentgame()
	 * @model derived="true"
	 * @generated
	 */
	TournamentGame getTournamentgame();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTournamentgame <em>Tournamentgame</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tournamentgame</em>' reference.
	 * @see #getTournamentgame()
	 * @generated
	 */
	void setTournamentgame(TournamentGame value);

	/**
	 * Returns the value of the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Title</em>' attribute.
	 * @see #setTitle(String)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Title()
	 * @model
	 * @generated
	 */
	String getTitle();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getTitle <em>Title</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Title</em>' attribute.
	 * @see #getTitle()
	 * @generated
	 */
	void setTitle(String value);

	/**
	 * Returns the value of the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Genre</em>' attribute.
	 * @see #setGenre(String)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Genre()
	 * @model
	 * @generated
	 */
	String getGenre();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getGenre <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Genre</em>' attribute.
	 * @see #getGenre()
	 * @generated
	 */
	void setGenre(String value);

	/**
	 * Returns the value of the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rating</em>' attribute.
	 * @see #setRating(int)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_Rating()
	 * @model
	 * @generated
	 */
	int getRating();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getRating <em>Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rating</em>' attribute.
	 * @see #getRating()
	 * @generated
	 */
	void setRating(int value);

	/**
	 * Returns the value of the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Release Date</em>' attribute.
	 * @see #setReleaseDate(Date)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGame_ReleaseDate()
	 * @model
	 * @generated
	 */
	Date getReleaseDate();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.Game#getReleaseDate <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Date</em>' attribute.
	 * @see #getReleaseDate()
	 * @generated
	 */
	void setReleaseDate(Date value);

} // Game
