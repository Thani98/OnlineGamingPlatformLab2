/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Single Player Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame#getDifficultyLevels <em>Difficulty Levels</em>}</li>
 * </ul>
 *
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getSinglePlayerGame()
 * @model
 * @generated
 */
public interface SinglePlayerGame extends Game {
	/**
	 * Returns the value of the '<em><b>Difficulty Levels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Difficulty Levels</em>' attribute.
	 * @see #setDifficultyLevels(int)
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getSinglePlayerGame_DifficultyLevels()
	 * @model
	 * @generated
	 */
	int getDifficultyLevels();

	/**
	 * Sets the value of the '{@link onlinegamingplatform.metamodel.onlinegamingplatform.SinglePlayerGame#getDifficultyLevels <em>Difficulty Levels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Difficulty Levels</em>' attribute.
	 * @see #getDifficultyLevels()
	 * @generated
	 */
	void setDifficultyLevels(int value);

} // SinglePlayerGame
