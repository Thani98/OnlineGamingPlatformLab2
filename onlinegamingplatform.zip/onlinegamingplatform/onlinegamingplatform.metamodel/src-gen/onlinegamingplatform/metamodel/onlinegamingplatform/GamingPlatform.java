/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gaming Platform</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link onlinegamingplatform.metamodel.onlinegamingplatform.GamingPlatform#getGames <em>Games</em>}</li>
 * </ul>
 *
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGamingPlatform()
 * @model
 * @generated
 */
public interface GamingPlatform extends EObject {
	/**
	 * Returns the value of the '<em><b>Games</b></em>' containment reference list.
	 * The list contents are of type {@link onlinegamingplatform.metamodel.onlinegamingplatform.Game}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Games</em>' containment reference list.
	 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage#getGamingPlatform_Games()
	 * @model containment="true"
	 * @generated
	 */
	EList<Game> getGames();

} // GamingPlatform
