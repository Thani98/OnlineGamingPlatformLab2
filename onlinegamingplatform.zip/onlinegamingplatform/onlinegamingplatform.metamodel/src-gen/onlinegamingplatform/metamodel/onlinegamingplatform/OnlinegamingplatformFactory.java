/**
 */
package onlinegamingplatform.metamodel.onlinegamingplatform;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see onlinegamingplatform.metamodel.onlinegamingplatform.OnlinegamingplatformPackage
 * @generated
 */
public interface OnlinegamingplatformFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	OnlinegamingplatformFactory eINSTANCE = onlinegamingplatform.metamodel.onlinegamingplatform.impl.OnlinegamingplatformFactoryImpl
			.init();

	/**
	 * Returns a new object of class '<em>Gaming Platform</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Gaming Platform</em>'.
	 * @generated
	 */
	GamingPlatform createGamingPlatform();

	/**
	 * Returns a new object of class '<em>Multiplayer Game</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Multiplayer Game</em>'.
	 * @generated
	 */
	MultiplayerGame createMultiplayerGame();

	/**
	 * Returns a new object of class '<em>Tournament Game</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tournament Game</em>'.
	 * @generated
	 */
	TournamentGame createTournamentGame();

	/**
	 * Returns a new object of class '<em>Single Player Game</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Single Player Game</em>'.
	 * @generated
	 */
	SinglePlayerGame createSinglePlayerGame();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	OnlinegamingplatformPackage getOnlinegamingplatformPackage();

} //OnlinegamingplatformFactory
