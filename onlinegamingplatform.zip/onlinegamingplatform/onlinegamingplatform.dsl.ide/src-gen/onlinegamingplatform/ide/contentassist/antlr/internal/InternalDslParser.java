package onlinegamingplatform.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import onlinegamingplatform.services.DslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'EDate'", "'GamingPlatform'", "'{'", "'}'", "'games'", "','", "'-'", "'MultiplayerGame'", "'title'", "'genre'", "'rating'", "'releaseDate'", "'maxPlayers'", "'TournamentGame'", "'tournamentFormat'", "'SinglePlayerGame'", "'difficultyLevels'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDsl.g"; }


    	private DslGrammarAccess grammarAccess;

    	public void setGrammarAccess(DslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleGamingPlatform"
    // InternalDsl.g:53:1: entryRuleGamingPlatform : ruleGamingPlatform EOF ;
    public final void entryRuleGamingPlatform() throws RecognitionException {
        try {
            // InternalDsl.g:54:1: ( ruleGamingPlatform EOF )
            // InternalDsl.g:55:1: ruleGamingPlatform EOF
            {
             before(grammarAccess.getGamingPlatformRule()); 
            pushFollow(FOLLOW_1);
            ruleGamingPlatform();

            state._fsp--;

             after(grammarAccess.getGamingPlatformRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGamingPlatform"


    // $ANTLR start "ruleGamingPlatform"
    // InternalDsl.g:62:1: ruleGamingPlatform : ( ( rule__GamingPlatform__Group__0 ) ) ;
    public final void ruleGamingPlatform() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:66:2: ( ( ( rule__GamingPlatform__Group__0 ) ) )
            // InternalDsl.g:67:2: ( ( rule__GamingPlatform__Group__0 ) )
            {
            // InternalDsl.g:67:2: ( ( rule__GamingPlatform__Group__0 ) )
            // InternalDsl.g:68:3: ( rule__GamingPlatform__Group__0 )
            {
             before(grammarAccess.getGamingPlatformAccess().getGroup()); 
            // InternalDsl.g:69:3: ( rule__GamingPlatform__Group__0 )
            // InternalDsl.g:69:4: rule__GamingPlatform__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGamingPlatformAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGamingPlatform"


    // $ANTLR start "entryRuleGame"
    // InternalDsl.g:78:1: entryRuleGame : ruleGame EOF ;
    public final void entryRuleGame() throws RecognitionException {
        try {
            // InternalDsl.g:79:1: ( ruleGame EOF )
            // InternalDsl.g:80:1: ruleGame EOF
            {
             before(grammarAccess.getGameRule()); 
            pushFollow(FOLLOW_1);
            ruleGame();

            state._fsp--;

             after(grammarAccess.getGameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGame"


    // $ANTLR start "ruleGame"
    // InternalDsl.g:87:1: ruleGame : ( ( rule__Game__Alternatives ) ) ;
    public final void ruleGame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:91:2: ( ( ( rule__Game__Alternatives ) ) )
            // InternalDsl.g:92:2: ( ( rule__Game__Alternatives ) )
            {
            // InternalDsl.g:92:2: ( ( rule__Game__Alternatives ) )
            // InternalDsl.g:93:3: ( rule__Game__Alternatives )
            {
             before(grammarAccess.getGameAccess().getAlternatives()); 
            // InternalDsl.g:94:3: ( rule__Game__Alternatives )
            // InternalDsl.g:94:4: rule__Game__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Game__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGame"


    // $ANTLR start "entryRuleEString"
    // InternalDsl.g:103:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalDsl.g:104:1: ( ruleEString EOF )
            // InternalDsl.g:105:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalDsl.g:112:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:116:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalDsl.g:117:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalDsl.g:117:2: ( ( rule__EString__Alternatives ) )
            // InternalDsl.g:118:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalDsl.g:119:3: ( rule__EString__Alternatives )
            // InternalDsl.g:119:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleEInt"
    // InternalDsl.g:128:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalDsl.g:129:1: ( ruleEInt EOF )
            // InternalDsl.g:130:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalDsl.g:137:1: ruleEInt : ( ( rule__EInt__Group__0 ) ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:141:2: ( ( ( rule__EInt__Group__0 ) ) )
            // InternalDsl.g:142:2: ( ( rule__EInt__Group__0 ) )
            {
            // InternalDsl.g:142:2: ( ( rule__EInt__Group__0 ) )
            // InternalDsl.g:143:3: ( rule__EInt__Group__0 )
            {
             before(grammarAccess.getEIntAccess().getGroup()); 
            // InternalDsl.g:144:3: ( rule__EInt__Group__0 )
            // InternalDsl.g:144:4: rule__EInt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEIntAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEDate"
    // InternalDsl.g:153:1: entryRuleEDate : ruleEDate EOF ;
    public final void entryRuleEDate() throws RecognitionException {
        try {
            // InternalDsl.g:154:1: ( ruleEDate EOF )
            // InternalDsl.g:155:1: ruleEDate EOF
            {
             before(grammarAccess.getEDateRule()); 
            pushFollow(FOLLOW_1);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getEDateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEDate"


    // $ANTLR start "ruleEDate"
    // InternalDsl.g:162:1: ruleEDate : ( 'EDate' ) ;
    public final void ruleEDate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:166:2: ( ( 'EDate' ) )
            // InternalDsl.g:167:2: ( 'EDate' )
            {
            // InternalDsl.g:167:2: ( 'EDate' )
            // InternalDsl.g:168:3: 'EDate'
            {
             before(grammarAccess.getEDateAccess().getEDateKeyword()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getEDateAccess().getEDateKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEDate"


    // $ANTLR start "entryRuleMultiplayerGame"
    // InternalDsl.g:178:1: entryRuleMultiplayerGame : ruleMultiplayerGame EOF ;
    public final void entryRuleMultiplayerGame() throws RecognitionException {
        try {
            // InternalDsl.g:179:1: ( ruleMultiplayerGame EOF )
            // InternalDsl.g:180:1: ruleMultiplayerGame EOF
            {
             before(grammarAccess.getMultiplayerGameRule()); 
            pushFollow(FOLLOW_1);
            ruleMultiplayerGame();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMultiplayerGame"


    // $ANTLR start "ruleMultiplayerGame"
    // InternalDsl.g:187:1: ruleMultiplayerGame : ( ( rule__MultiplayerGame__Group__0 ) ) ;
    public final void ruleMultiplayerGame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:191:2: ( ( ( rule__MultiplayerGame__Group__0 ) ) )
            // InternalDsl.g:192:2: ( ( rule__MultiplayerGame__Group__0 ) )
            {
            // InternalDsl.g:192:2: ( ( rule__MultiplayerGame__Group__0 ) )
            // InternalDsl.g:193:3: ( rule__MultiplayerGame__Group__0 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup()); 
            // InternalDsl.g:194:3: ( rule__MultiplayerGame__Group__0 )
            // InternalDsl.g:194:4: rule__MultiplayerGame__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMultiplayerGame"


    // $ANTLR start "entryRuleTournamentGame"
    // InternalDsl.g:203:1: entryRuleTournamentGame : ruleTournamentGame EOF ;
    public final void entryRuleTournamentGame() throws RecognitionException {
        try {
            // InternalDsl.g:204:1: ( ruleTournamentGame EOF )
            // InternalDsl.g:205:1: ruleTournamentGame EOF
            {
             before(grammarAccess.getTournamentGameRule()); 
            pushFollow(FOLLOW_1);
            ruleTournamentGame();

            state._fsp--;

             after(grammarAccess.getTournamentGameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTournamentGame"


    // $ANTLR start "ruleTournamentGame"
    // InternalDsl.g:212:1: ruleTournamentGame : ( ( rule__TournamentGame__Group__0 ) ) ;
    public final void ruleTournamentGame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:216:2: ( ( ( rule__TournamentGame__Group__0 ) ) )
            // InternalDsl.g:217:2: ( ( rule__TournamentGame__Group__0 ) )
            {
            // InternalDsl.g:217:2: ( ( rule__TournamentGame__Group__0 ) )
            // InternalDsl.g:218:3: ( rule__TournamentGame__Group__0 )
            {
             before(grammarAccess.getTournamentGameAccess().getGroup()); 
            // InternalDsl.g:219:3: ( rule__TournamentGame__Group__0 )
            // InternalDsl.g:219:4: rule__TournamentGame__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTournamentGame"


    // $ANTLR start "entryRuleSinglePlayerGame"
    // InternalDsl.g:228:1: entryRuleSinglePlayerGame : ruleSinglePlayerGame EOF ;
    public final void entryRuleSinglePlayerGame() throws RecognitionException {
        try {
            // InternalDsl.g:229:1: ( ruleSinglePlayerGame EOF )
            // InternalDsl.g:230:1: ruleSinglePlayerGame EOF
            {
             before(grammarAccess.getSinglePlayerGameRule()); 
            pushFollow(FOLLOW_1);
            ruleSinglePlayerGame();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSinglePlayerGame"


    // $ANTLR start "ruleSinglePlayerGame"
    // InternalDsl.g:237:1: ruleSinglePlayerGame : ( ( rule__SinglePlayerGame__Group__0 ) ) ;
    public final void ruleSinglePlayerGame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:241:2: ( ( ( rule__SinglePlayerGame__Group__0 ) ) )
            // InternalDsl.g:242:2: ( ( rule__SinglePlayerGame__Group__0 ) )
            {
            // InternalDsl.g:242:2: ( ( rule__SinglePlayerGame__Group__0 ) )
            // InternalDsl.g:243:3: ( rule__SinglePlayerGame__Group__0 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup()); 
            // InternalDsl.g:244:3: ( rule__SinglePlayerGame__Group__0 )
            // InternalDsl.g:244:4: rule__SinglePlayerGame__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSinglePlayerGame"


    // $ANTLR start "rule__Game__Alternatives"
    // InternalDsl.g:252:1: rule__Game__Alternatives : ( ( ruleMultiplayerGame ) | ( ruleTournamentGame ) | ( ruleSinglePlayerGame ) );
    public final void rule__Game__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:256:1: ( ( ruleMultiplayerGame ) | ( ruleTournamentGame ) | ( ruleSinglePlayerGame ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt1=1;
                }
                break;
            case 24:
                {
                alt1=2;
                }
                break;
            case 26:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalDsl.g:257:2: ( ruleMultiplayerGame )
                    {
                    // InternalDsl.g:257:2: ( ruleMultiplayerGame )
                    // InternalDsl.g:258:3: ruleMultiplayerGame
                    {
                     before(grammarAccess.getGameAccess().getMultiplayerGameParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMultiplayerGame();

                    state._fsp--;

                     after(grammarAccess.getGameAccess().getMultiplayerGameParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDsl.g:263:2: ( ruleTournamentGame )
                    {
                    // InternalDsl.g:263:2: ( ruleTournamentGame )
                    // InternalDsl.g:264:3: ruleTournamentGame
                    {
                     before(grammarAccess.getGameAccess().getTournamentGameParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleTournamentGame();

                    state._fsp--;

                     after(grammarAccess.getGameAccess().getTournamentGameParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalDsl.g:269:2: ( ruleSinglePlayerGame )
                    {
                    // InternalDsl.g:269:2: ( ruleSinglePlayerGame )
                    // InternalDsl.g:270:3: ruleSinglePlayerGame
                    {
                     before(grammarAccess.getGameAccess().getSinglePlayerGameParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleSinglePlayerGame();

                    state._fsp--;

                     after(grammarAccess.getGameAccess().getSinglePlayerGameParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Alternatives"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalDsl.g:279:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:283:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_STRING) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_ID) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalDsl.g:284:2: ( RULE_STRING )
                    {
                    // InternalDsl.g:284:2: ( RULE_STRING )
                    // InternalDsl.g:285:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDsl.g:290:2: ( RULE_ID )
                    {
                    // InternalDsl.g:290:2: ( RULE_ID )
                    // InternalDsl.g:291:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__GamingPlatform__Group__0"
    // InternalDsl.g:300:1: rule__GamingPlatform__Group__0 : rule__GamingPlatform__Group__0__Impl rule__GamingPlatform__Group__1 ;
    public final void rule__GamingPlatform__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:304:1: ( rule__GamingPlatform__Group__0__Impl rule__GamingPlatform__Group__1 )
            // InternalDsl.g:305:2: rule__GamingPlatform__Group__0__Impl rule__GamingPlatform__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__GamingPlatform__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__0"


    // $ANTLR start "rule__GamingPlatform__Group__0__Impl"
    // InternalDsl.g:312:1: rule__GamingPlatform__Group__0__Impl : ( () ) ;
    public final void rule__GamingPlatform__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:316:1: ( ( () ) )
            // InternalDsl.g:317:1: ( () )
            {
            // InternalDsl.g:317:1: ( () )
            // InternalDsl.g:318:2: ()
            {
             before(grammarAccess.getGamingPlatformAccess().getGamingPlatformAction_0()); 
            // InternalDsl.g:319:2: ()
            // InternalDsl.g:319:3: 
            {
            }

             after(grammarAccess.getGamingPlatformAccess().getGamingPlatformAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__0__Impl"


    // $ANTLR start "rule__GamingPlatform__Group__1"
    // InternalDsl.g:327:1: rule__GamingPlatform__Group__1 : rule__GamingPlatform__Group__1__Impl rule__GamingPlatform__Group__2 ;
    public final void rule__GamingPlatform__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:331:1: ( rule__GamingPlatform__Group__1__Impl rule__GamingPlatform__Group__2 )
            // InternalDsl.g:332:2: rule__GamingPlatform__Group__1__Impl rule__GamingPlatform__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__GamingPlatform__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__1"


    // $ANTLR start "rule__GamingPlatform__Group__1__Impl"
    // InternalDsl.g:339:1: rule__GamingPlatform__Group__1__Impl : ( 'GamingPlatform' ) ;
    public final void rule__GamingPlatform__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:343:1: ( ( 'GamingPlatform' ) )
            // InternalDsl.g:344:1: ( 'GamingPlatform' )
            {
            // InternalDsl.g:344:1: ( 'GamingPlatform' )
            // InternalDsl.g:345:2: 'GamingPlatform'
            {
             before(grammarAccess.getGamingPlatformAccess().getGamingPlatformKeyword_1()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getGamingPlatformKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__1__Impl"


    // $ANTLR start "rule__GamingPlatform__Group__2"
    // InternalDsl.g:354:1: rule__GamingPlatform__Group__2 : rule__GamingPlatform__Group__2__Impl rule__GamingPlatform__Group__3 ;
    public final void rule__GamingPlatform__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:358:1: ( rule__GamingPlatform__Group__2__Impl rule__GamingPlatform__Group__3 )
            // InternalDsl.g:359:2: rule__GamingPlatform__Group__2__Impl rule__GamingPlatform__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__GamingPlatform__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__2"


    // $ANTLR start "rule__GamingPlatform__Group__2__Impl"
    // InternalDsl.g:366:1: rule__GamingPlatform__Group__2__Impl : ( '{' ) ;
    public final void rule__GamingPlatform__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:370:1: ( ( '{' ) )
            // InternalDsl.g:371:1: ( '{' )
            {
            // InternalDsl.g:371:1: ( '{' )
            // InternalDsl.g:372:2: '{'
            {
             before(grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__2__Impl"


    // $ANTLR start "rule__GamingPlatform__Group__3"
    // InternalDsl.g:381:1: rule__GamingPlatform__Group__3 : rule__GamingPlatform__Group__3__Impl rule__GamingPlatform__Group__4 ;
    public final void rule__GamingPlatform__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:385:1: ( rule__GamingPlatform__Group__3__Impl rule__GamingPlatform__Group__4 )
            // InternalDsl.g:386:2: rule__GamingPlatform__Group__3__Impl rule__GamingPlatform__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__GamingPlatform__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__3"


    // $ANTLR start "rule__GamingPlatform__Group__3__Impl"
    // InternalDsl.g:393:1: rule__GamingPlatform__Group__3__Impl : ( ( rule__GamingPlatform__Group_3__0 )? ) ;
    public final void rule__GamingPlatform__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:397:1: ( ( ( rule__GamingPlatform__Group_3__0 )? ) )
            // InternalDsl.g:398:1: ( ( rule__GamingPlatform__Group_3__0 )? )
            {
            // InternalDsl.g:398:1: ( ( rule__GamingPlatform__Group_3__0 )? )
            // InternalDsl.g:399:2: ( rule__GamingPlatform__Group_3__0 )?
            {
             before(grammarAccess.getGamingPlatformAccess().getGroup_3()); 
            // InternalDsl.g:400:2: ( rule__GamingPlatform__Group_3__0 )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==15) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalDsl.g:400:3: rule__GamingPlatform__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GamingPlatform__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGamingPlatformAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__3__Impl"


    // $ANTLR start "rule__GamingPlatform__Group__4"
    // InternalDsl.g:408:1: rule__GamingPlatform__Group__4 : rule__GamingPlatform__Group__4__Impl ;
    public final void rule__GamingPlatform__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:412:1: ( rule__GamingPlatform__Group__4__Impl )
            // InternalDsl.g:413:2: rule__GamingPlatform__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__4"


    // $ANTLR start "rule__GamingPlatform__Group__4__Impl"
    // InternalDsl.g:419:1: rule__GamingPlatform__Group__4__Impl : ( '}' ) ;
    public final void rule__GamingPlatform__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:423:1: ( ( '}' ) )
            // InternalDsl.g:424:1: ( '}' )
            {
            // InternalDsl.g:424:1: ( '}' )
            // InternalDsl.g:425:2: '}'
            {
             before(grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_4()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group__4__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3__0"
    // InternalDsl.g:435:1: rule__GamingPlatform__Group_3__0 : rule__GamingPlatform__Group_3__0__Impl rule__GamingPlatform__Group_3__1 ;
    public final void rule__GamingPlatform__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:439:1: ( rule__GamingPlatform__Group_3__0__Impl rule__GamingPlatform__Group_3__1 )
            // InternalDsl.g:440:2: rule__GamingPlatform__Group_3__0__Impl rule__GamingPlatform__Group_3__1
            {
            pushFollow(FOLLOW_4);
            rule__GamingPlatform__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__0"


    // $ANTLR start "rule__GamingPlatform__Group_3__0__Impl"
    // InternalDsl.g:447:1: rule__GamingPlatform__Group_3__0__Impl : ( 'games' ) ;
    public final void rule__GamingPlatform__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:451:1: ( ( 'games' ) )
            // InternalDsl.g:452:1: ( 'games' )
            {
            // InternalDsl.g:452:1: ( 'games' )
            // InternalDsl.g:453:2: 'games'
            {
             before(grammarAccess.getGamingPlatformAccess().getGamesKeyword_3_0()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getGamesKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__0__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3__1"
    // InternalDsl.g:462:1: rule__GamingPlatform__Group_3__1 : rule__GamingPlatform__Group_3__1__Impl rule__GamingPlatform__Group_3__2 ;
    public final void rule__GamingPlatform__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:466:1: ( rule__GamingPlatform__Group_3__1__Impl rule__GamingPlatform__Group_3__2 )
            // InternalDsl.g:467:2: rule__GamingPlatform__Group_3__1__Impl rule__GamingPlatform__Group_3__2
            {
            pushFollow(FOLLOW_6);
            rule__GamingPlatform__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__1"


    // $ANTLR start "rule__GamingPlatform__Group_3__1__Impl"
    // InternalDsl.g:474:1: rule__GamingPlatform__Group_3__1__Impl : ( '{' ) ;
    public final void rule__GamingPlatform__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:478:1: ( ( '{' ) )
            // InternalDsl.g:479:1: ( '{' )
            {
            // InternalDsl.g:479:1: ( '{' )
            // InternalDsl.g:480:2: '{'
            {
             before(grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_3_1()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getLeftCurlyBracketKeyword_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__1__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3__2"
    // InternalDsl.g:489:1: rule__GamingPlatform__Group_3__2 : rule__GamingPlatform__Group_3__2__Impl rule__GamingPlatform__Group_3__3 ;
    public final void rule__GamingPlatform__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:493:1: ( rule__GamingPlatform__Group_3__2__Impl rule__GamingPlatform__Group_3__3 )
            // InternalDsl.g:494:2: rule__GamingPlatform__Group_3__2__Impl rule__GamingPlatform__Group_3__3
            {
            pushFollow(FOLLOW_7);
            rule__GamingPlatform__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__2"


    // $ANTLR start "rule__GamingPlatform__Group_3__2__Impl"
    // InternalDsl.g:501:1: rule__GamingPlatform__Group_3__2__Impl : ( ( rule__GamingPlatform__GamesAssignment_3_2 ) ) ;
    public final void rule__GamingPlatform__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:505:1: ( ( ( rule__GamingPlatform__GamesAssignment_3_2 ) ) )
            // InternalDsl.g:506:1: ( ( rule__GamingPlatform__GamesAssignment_3_2 ) )
            {
            // InternalDsl.g:506:1: ( ( rule__GamingPlatform__GamesAssignment_3_2 ) )
            // InternalDsl.g:507:2: ( rule__GamingPlatform__GamesAssignment_3_2 )
            {
             before(grammarAccess.getGamingPlatformAccess().getGamesAssignment_3_2()); 
            // InternalDsl.g:508:2: ( rule__GamingPlatform__GamesAssignment_3_2 )
            // InternalDsl.g:508:3: rule__GamingPlatform__GamesAssignment_3_2
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__GamesAssignment_3_2();

            state._fsp--;


            }

             after(grammarAccess.getGamingPlatformAccess().getGamesAssignment_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__2__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3__3"
    // InternalDsl.g:516:1: rule__GamingPlatform__Group_3__3 : rule__GamingPlatform__Group_3__3__Impl rule__GamingPlatform__Group_3__4 ;
    public final void rule__GamingPlatform__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:520:1: ( rule__GamingPlatform__Group_3__3__Impl rule__GamingPlatform__Group_3__4 )
            // InternalDsl.g:521:2: rule__GamingPlatform__Group_3__3__Impl rule__GamingPlatform__Group_3__4
            {
            pushFollow(FOLLOW_7);
            rule__GamingPlatform__Group_3__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__3"


    // $ANTLR start "rule__GamingPlatform__Group_3__3__Impl"
    // InternalDsl.g:528:1: rule__GamingPlatform__Group_3__3__Impl : ( ( rule__GamingPlatform__Group_3_3__0 )* ) ;
    public final void rule__GamingPlatform__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:532:1: ( ( ( rule__GamingPlatform__Group_3_3__0 )* ) )
            // InternalDsl.g:533:1: ( ( rule__GamingPlatform__Group_3_3__0 )* )
            {
            // InternalDsl.g:533:1: ( ( rule__GamingPlatform__Group_3_3__0 )* )
            // InternalDsl.g:534:2: ( rule__GamingPlatform__Group_3_3__0 )*
            {
             before(grammarAccess.getGamingPlatformAccess().getGroup_3_3()); 
            // InternalDsl.g:535:2: ( rule__GamingPlatform__Group_3_3__0 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==16) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalDsl.g:535:3: rule__GamingPlatform__Group_3_3__0
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__GamingPlatform__Group_3_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getGamingPlatformAccess().getGroup_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__3__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3__4"
    // InternalDsl.g:543:1: rule__GamingPlatform__Group_3__4 : rule__GamingPlatform__Group_3__4__Impl ;
    public final void rule__GamingPlatform__Group_3__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:547:1: ( rule__GamingPlatform__Group_3__4__Impl )
            // InternalDsl.g:548:2: rule__GamingPlatform__Group_3__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__4"


    // $ANTLR start "rule__GamingPlatform__Group_3__4__Impl"
    // InternalDsl.g:554:1: rule__GamingPlatform__Group_3__4__Impl : ( '}' ) ;
    public final void rule__GamingPlatform__Group_3__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:558:1: ( ( '}' ) )
            // InternalDsl.g:559:1: ( '}' )
            {
            // InternalDsl.g:559:1: ( '}' )
            // InternalDsl.g:560:2: '}'
            {
             before(grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_3_4()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getRightCurlyBracketKeyword_3_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3__4__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3_3__0"
    // InternalDsl.g:570:1: rule__GamingPlatform__Group_3_3__0 : rule__GamingPlatform__Group_3_3__0__Impl rule__GamingPlatform__Group_3_3__1 ;
    public final void rule__GamingPlatform__Group_3_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:574:1: ( rule__GamingPlatform__Group_3_3__0__Impl rule__GamingPlatform__Group_3_3__1 )
            // InternalDsl.g:575:2: rule__GamingPlatform__Group_3_3__0__Impl rule__GamingPlatform__Group_3_3__1
            {
            pushFollow(FOLLOW_6);
            rule__GamingPlatform__Group_3_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3_3__0"


    // $ANTLR start "rule__GamingPlatform__Group_3_3__0__Impl"
    // InternalDsl.g:582:1: rule__GamingPlatform__Group_3_3__0__Impl : ( ',' ) ;
    public final void rule__GamingPlatform__Group_3_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:586:1: ( ( ',' ) )
            // InternalDsl.g:587:1: ( ',' )
            {
            // InternalDsl.g:587:1: ( ',' )
            // InternalDsl.g:588:2: ','
            {
             before(grammarAccess.getGamingPlatformAccess().getCommaKeyword_3_3_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGamingPlatformAccess().getCommaKeyword_3_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3_3__0__Impl"


    // $ANTLR start "rule__GamingPlatform__Group_3_3__1"
    // InternalDsl.g:597:1: rule__GamingPlatform__Group_3_3__1 : rule__GamingPlatform__Group_3_3__1__Impl ;
    public final void rule__GamingPlatform__Group_3_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:601:1: ( rule__GamingPlatform__Group_3_3__1__Impl )
            // InternalDsl.g:602:2: rule__GamingPlatform__Group_3_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__Group_3_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3_3__1"


    // $ANTLR start "rule__GamingPlatform__Group_3_3__1__Impl"
    // InternalDsl.g:608:1: rule__GamingPlatform__Group_3_3__1__Impl : ( ( rule__GamingPlatform__GamesAssignment_3_3_1 ) ) ;
    public final void rule__GamingPlatform__Group_3_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:612:1: ( ( ( rule__GamingPlatform__GamesAssignment_3_3_1 ) ) )
            // InternalDsl.g:613:1: ( ( rule__GamingPlatform__GamesAssignment_3_3_1 ) )
            {
            // InternalDsl.g:613:1: ( ( rule__GamingPlatform__GamesAssignment_3_3_1 ) )
            // InternalDsl.g:614:2: ( rule__GamingPlatform__GamesAssignment_3_3_1 )
            {
             before(grammarAccess.getGamingPlatformAccess().getGamesAssignment_3_3_1()); 
            // InternalDsl.g:615:2: ( rule__GamingPlatform__GamesAssignment_3_3_1 )
            // InternalDsl.g:615:3: rule__GamingPlatform__GamesAssignment_3_3_1
            {
            pushFollow(FOLLOW_2);
            rule__GamingPlatform__GamesAssignment_3_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGamingPlatformAccess().getGamesAssignment_3_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__Group_3_3__1__Impl"


    // $ANTLR start "rule__EInt__Group__0"
    // InternalDsl.g:624:1: rule__EInt__Group__0 : rule__EInt__Group__0__Impl rule__EInt__Group__1 ;
    public final void rule__EInt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:628:1: ( rule__EInt__Group__0__Impl rule__EInt__Group__1 )
            // InternalDsl.g:629:2: rule__EInt__Group__0__Impl rule__EInt__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__EInt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EInt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0"


    // $ANTLR start "rule__EInt__Group__0__Impl"
    // InternalDsl.g:636:1: rule__EInt__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EInt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:640:1: ( ( ( '-' )? ) )
            // InternalDsl.g:641:1: ( ( '-' )? )
            {
            // InternalDsl.g:641:1: ( ( '-' )? )
            // InternalDsl.g:642:2: ( '-' )?
            {
             before(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 
            // InternalDsl.g:643:2: ( '-' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalDsl.g:643:3: '-'
                    {
                    match(input,17,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0__Impl"


    // $ANTLR start "rule__EInt__Group__1"
    // InternalDsl.g:651:1: rule__EInt__Group__1 : rule__EInt__Group__1__Impl ;
    public final void rule__EInt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:655:1: ( rule__EInt__Group__1__Impl )
            // InternalDsl.g:656:2: rule__EInt__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1"


    // $ANTLR start "rule__EInt__Group__1__Impl"
    // InternalDsl.g:662:1: rule__EInt__Group__1__Impl : ( RULE_INT ) ;
    public final void rule__EInt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:666:1: ( ( RULE_INT ) )
            // InternalDsl.g:667:1: ( RULE_INT )
            {
            // InternalDsl.g:667:1: ( RULE_INT )
            // InternalDsl.g:668:2: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__0"
    // InternalDsl.g:678:1: rule__MultiplayerGame__Group__0 : rule__MultiplayerGame__Group__0__Impl rule__MultiplayerGame__Group__1 ;
    public final void rule__MultiplayerGame__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:682:1: ( rule__MultiplayerGame__Group__0__Impl rule__MultiplayerGame__Group__1 )
            // InternalDsl.g:683:2: rule__MultiplayerGame__Group__0__Impl rule__MultiplayerGame__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__MultiplayerGame__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__0"


    // $ANTLR start "rule__MultiplayerGame__Group__0__Impl"
    // InternalDsl.g:690:1: rule__MultiplayerGame__Group__0__Impl : ( () ) ;
    public final void rule__MultiplayerGame__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:694:1: ( ( () ) )
            // InternalDsl.g:695:1: ( () )
            {
            // InternalDsl.g:695:1: ( () )
            // InternalDsl.g:696:2: ()
            {
             before(grammarAccess.getMultiplayerGameAccess().getMultiplayerGameAction_0()); 
            // InternalDsl.g:697:2: ()
            // InternalDsl.g:697:3: 
            {
            }

             after(grammarAccess.getMultiplayerGameAccess().getMultiplayerGameAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__1"
    // InternalDsl.g:705:1: rule__MultiplayerGame__Group__1 : rule__MultiplayerGame__Group__1__Impl rule__MultiplayerGame__Group__2 ;
    public final void rule__MultiplayerGame__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:709:1: ( rule__MultiplayerGame__Group__1__Impl rule__MultiplayerGame__Group__2 )
            // InternalDsl.g:710:2: rule__MultiplayerGame__Group__1__Impl rule__MultiplayerGame__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__MultiplayerGame__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__1"


    // $ANTLR start "rule__MultiplayerGame__Group__1__Impl"
    // InternalDsl.g:717:1: rule__MultiplayerGame__Group__1__Impl : ( 'MultiplayerGame' ) ;
    public final void rule__MultiplayerGame__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:721:1: ( ( 'MultiplayerGame' ) )
            // InternalDsl.g:722:1: ( 'MultiplayerGame' )
            {
            // InternalDsl.g:722:1: ( 'MultiplayerGame' )
            // InternalDsl.g:723:2: 'MultiplayerGame'
            {
             before(grammarAccess.getMultiplayerGameAccess().getMultiplayerGameKeyword_1()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getMultiplayerGameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__2"
    // InternalDsl.g:732:1: rule__MultiplayerGame__Group__2 : rule__MultiplayerGame__Group__2__Impl rule__MultiplayerGame__Group__3 ;
    public final void rule__MultiplayerGame__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:736:1: ( rule__MultiplayerGame__Group__2__Impl rule__MultiplayerGame__Group__3 )
            // InternalDsl.g:737:2: rule__MultiplayerGame__Group__2__Impl rule__MultiplayerGame__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__2"


    // $ANTLR start "rule__MultiplayerGame__Group__2__Impl"
    // InternalDsl.g:744:1: rule__MultiplayerGame__Group__2__Impl : ( '{' ) ;
    public final void rule__MultiplayerGame__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:748:1: ( ( '{' ) )
            // InternalDsl.g:749:1: ( '{' )
            {
            // InternalDsl.g:749:1: ( '{' )
            // InternalDsl.g:750:2: '{'
            {
             before(grammarAccess.getMultiplayerGameAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__2__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__3"
    // InternalDsl.g:759:1: rule__MultiplayerGame__Group__3 : rule__MultiplayerGame__Group__3__Impl rule__MultiplayerGame__Group__4 ;
    public final void rule__MultiplayerGame__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:763:1: ( rule__MultiplayerGame__Group__3__Impl rule__MultiplayerGame__Group__4 )
            // InternalDsl.g:764:2: rule__MultiplayerGame__Group__3__Impl rule__MultiplayerGame__Group__4
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__3"


    // $ANTLR start "rule__MultiplayerGame__Group__3__Impl"
    // InternalDsl.g:771:1: rule__MultiplayerGame__Group__3__Impl : ( ( rule__MultiplayerGame__Group_3__0 )? ) ;
    public final void rule__MultiplayerGame__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:775:1: ( ( ( rule__MultiplayerGame__Group_3__0 )? ) )
            // InternalDsl.g:776:1: ( ( rule__MultiplayerGame__Group_3__0 )? )
            {
            // InternalDsl.g:776:1: ( ( rule__MultiplayerGame__Group_3__0 )? )
            // InternalDsl.g:777:2: ( rule__MultiplayerGame__Group_3__0 )?
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup_3()); 
            // InternalDsl.g:778:2: ( rule__MultiplayerGame__Group_3__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==19) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalDsl.g:778:3: rule__MultiplayerGame__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MultiplayerGame__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__3__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__4"
    // InternalDsl.g:786:1: rule__MultiplayerGame__Group__4 : rule__MultiplayerGame__Group__4__Impl rule__MultiplayerGame__Group__5 ;
    public final void rule__MultiplayerGame__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:790:1: ( rule__MultiplayerGame__Group__4__Impl rule__MultiplayerGame__Group__5 )
            // InternalDsl.g:791:2: rule__MultiplayerGame__Group__4__Impl rule__MultiplayerGame__Group__5
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__4"


    // $ANTLR start "rule__MultiplayerGame__Group__4__Impl"
    // InternalDsl.g:798:1: rule__MultiplayerGame__Group__4__Impl : ( ( rule__MultiplayerGame__Group_4__0 )? ) ;
    public final void rule__MultiplayerGame__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:802:1: ( ( ( rule__MultiplayerGame__Group_4__0 )? ) )
            // InternalDsl.g:803:1: ( ( rule__MultiplayerGame__Group_4__0 )? )
            {
            // InternalDsl.g:803:1: ( ( rule__MultiplayerGame__Group_4__0 )? )
            // InternalDsl.g:804:2: ( rule__MultiplayerGame__Group_4__0 )?
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup_4()); 
            // InternalDsl.g:805:2: ( rule__MultiplayerGame__Group_4__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalDsl.g:805:3: rule__MultiplayerGame__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MultiplayerGame__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__4__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__5"
    // InternalDsl.g:813:1: rule__MultiplayerGame__Group__5 : rule__MultiplayerGame__Group__5__Impl rule__MultiplayerGame__Group__6 ;
    public final void rule__MultiplayerGame__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:817:1: ( rule__MultiplayerGame__Group__5__Impl rule__MultiplayerGame__Group__6 )
            // InternalDsl.g:818:2: rule__MultiplayerGame__Group__5__Impl rule__MultiplayerGame__Group__6
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__5"


    // $ANTLR start "rule__MultiplayerGame__Group__5__Impl"
    // InternalDsl.g:825:1: rule__MultiplayerGame__Group__5__Impl : ( ( rule__MultiplayerGame__Group_5__0 )? ) ;
    public final void rule__MultiplayerGame__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:829:1: ( ( ( rule__MultiplayerGame__Group_5__0 )? ) )
            // InternalDsl.g:830:1: ( ( rule__MultiplayerGame__Group_5__0 )? )
            {
            // InternalDsl.g:830:1: ( ( rule__MultiplayerGame__Group_5__0 )? )
            // InternalDsl.g:831:2: ( rule__MultiplayerGame__Group_5__0 )?
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup_5()); 
            // InternalDsl.g:832:2: ( rule__MultiplayerGame__Group_5__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalDsl.g:832:3: rule__MultiplayerGame__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MultiplayerGame__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__5__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__6"
    // InternalDsl.g:840:1: rule__MultiplayerGame__Group__6 : rule__MultiplayerGame__Group__6__Impl rule__MultiplayerGame__Group__7 ;
    public final void rule__MultiplayerGame__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:844:1: ( rule__MultiplayerGame__Group__6__Impl rule__MultiplayerGame__Group__7 )
            // InternalDsl.g:845:2: rule__MultiplayerGame__Group__6__Impl rule__MultiplayerGame__Group__7
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__6"


    // $ANTLR start "rule__MultiplayerGame__Group__6__Impl"
    // InternalDsl.g:852:1: rule__MultiplayerGame__Group__6__Impl : ( ( rule__MultiplayerGame__Group_6__0 )? ) ;
    public final void rule__MultiplayerGame__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:856:1: ( ( ( rule__MultiplayerGame__Group_6__0 )? ) )
            // InternalDsl.g:857:1: ( ( rule__MultiplayerGame__Group_6__0 )? )
            {
            // InternalDsl.g:857:1: ( ( rule__MultiplayerGame__Group_6__0 )? )
            // InternalDsl.g:858:2: ( rule__MultiplayerGame__Group_6__0 )?
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup_6()); 
            // InternalDsl.g:859:2: ( rule__MultiplayerGame__Group_6__0 )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDsl.g:859:3: rule__MultiplayerGame__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MultiplayerGame__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__6__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__7"
    // InternalDsl.g:867:1: rule__MultiplayerGame__Group__7 : rule__MultiplayerGame__Group__7__Impl rule__MultiplayerGame__Group__8 ;
    public final void rule__MultiplayerGame__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:871:1: ( rule__MultiplayerGame__Group__7__Impl rule__MultiplayerGame__Group__8 )
            // InternalDsl.g:872:2: rule__MultiplayerGame__Group__7__Impl rule__MultiplayerGame__Group__8
            {
            pushFollow(FOLLOW_11);
            rule__MultiplayerGame__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__7"


    // $ANTLR start "rule__MultiplayerGame__Group__7__Impl"
    // InternalDsl.g:879:1: rule__MultiplayerGame__Group__7__Impl : ( ( rule__MultiplayerGame__Group_7__0 )? ) ;
    public final void rule__MultiplayerGame__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:883:1: ( ( ( rule__MultiplayerGame__Group_7__0 )? ) )
            // InternalDsl.g:884:1: ( ( rule__MultiplayerGame__Group_7__0 )? )
            {
            // InternalDsl.g:884:1: ( ( rule__MultiplayerGame__Group_7__0 )? )
            // InternalDsl.g:885:2: ( rule__MultiplayerGame__Group_7__0 )?
            {
             before(grammarAccess.getMultiplayerGameAccess().getGroup_7()); 
            // InternalDsl.g:886:2: ( rule__MultiplayerGame__Group_7__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==23) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalDsl.g:886:3: rule__MultiplayerGame__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__MultiplayerGame__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMultiplayerGameAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__7__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group__8"
    // InternalDsl.g:894:1: rule__MultiplayerGame__Group__8 : rule__MultiplayerGame__Group__8__Impl ;
    public final void rule__MultiplayerGame__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:898:1: ( rule__MultiplayerGame__Group__8__Impl )
            // InternalDsl.g:899:2: rule__MultiplayerGame__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__8"


    // $ANTLR start "rule__MultiplayerGame__Group__8__Impl"
    // InternalDsl.g:905:1: rule__MultiplayerGame__Group__8__Impl : ( '}' ) ;
    public final void rule__MultiplayerGame__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:909:1: ( ( '}' ) )
            // InternalDsl.g:910:1: ( '}' )
            {
            // InternalDsl.g:910:1: ( '}' )
            // InternalDsl.g:911:2: '}'
            {
             before(grammarAccess.getMultiplayerGameAccess().getRightCurlyBracketKeyword_8()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group__8__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_3__0"
    // InternalDsl.g:921:1: rule__MultiplayerGame__Group_3__0 : rule__MultiplayerGame__Group_3__0__Impl rule__MultiplayerGame__Group_3__1 ;
    public final void rule__MultiplayerGame__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:925:1: ( rule__MultiplayerGame__Group_3__0__Impl rule__MultiplayerGame__Group_3__1 )
            // InternalDsl.g:926:2: rule__MultiplayerGame__Group_3__0__Impl rule__MultiplayerGame__Group_3__1
            {
            pushFollow(FOLLOW_12);
            rule__MultiplayerGame__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_3__0"


    // $ANTLR start "rule__MultiplayerGame__Group_3__0__Impl"
    // InternalDsl.g:933:1: rule__MultiplayerGame__Group_3__0__Impl : ( 'title' ) ;
    public final void rule__MultiplayerGame__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:937:1: ( ( 'title' ) )
            // InternalDsl.g:938:1: ( 'title' )
            {
            // InternalDsl.g:938:1: ( 'title' )
            // InternalDsl.g:939:2: 'title'
            {
             before(grammarAccess.getMultiplayerGameAccess().getTitleKeyword_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getTitleKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_3__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_3__1"
    // InternalDsl.g:948:1: rule__MultiplayerGame__Group_3__1 : rule__MultiplayerGame__Group_3__1__Impl ;
    public final void rule__MultiplayerGame__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:952:1: ( rule__MultiplayerGame__Group_3__1__Impl )
            // InternalDsl.g:953:2: rule__MultiplayerGame__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_3__1"


    // $ANTLR start "rule__MultiplayerGame__Group_3__1__Impl"
    // InternalDsl.g:959:1: rule__MultiplayerGame__Group_3__1__Impl : ( ( rule__MultiplayerGame__TitleAssignment_3_1 ) ) ;
    public final void rule__MultiplayerGame__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:963:1: ( ( ( rule__MultiplayerGame__TitleAssignment_3_1 ) ) )
            // InternalDsl.g:964:1: ( ( rule__MultiplayerGame__TitleAssignment_3_1 ) )
            {
            // InternalDsl.g:964:1: ( ( rule__MultiplayerGame__TitleAssignment_3_1 ) )
            // InternalDsl.g:965:2: ( rule__MultiplayerGame__TitleAssignment_3_1 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getTitleAssignment_3_1()); 
            // InternalDsl.g:966:2: ( rule__MultiplayerGame__TitleAssignment_3_1 )
            // InternalDsl.g:966:3: rule__MultiplayerGame__TitleAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__TitleAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getTitleAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_3__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_4__0"
    // InternalDsl.g:975:1: rule__MultiplayerGame__Group_4__0 : rule__MultiplayerGame__Group_4__0__Impl rule__MultiplayerGame__Group_4__1 ;
    public final void rule__MultiplayerGame__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:979:1: ( rule__MultiplayerGame__Group_4__0__Impl rule__MultiplayerGame__Group_4__1 )
            // InternalDsl.g:980:2: rule__MultiplayerGame__Group_4__0__Impl rule__MultiplayerGame__Group_4__1
            {
            pushFollow(FOLLOW_12);
            rule__MultiplayerGame__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_4__0"


    // $ANTLR start "rule__MultiplayerGame__Group_4__0__Impl"
    // InternalDsl.g:987:1: rule__MultiplayerGame__Group_4__0__Impl : ( 'genre' ) ;
    public final void rule__MultiplayerGame__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:991:1: ( ( 'genre' ) )
            // InternalDsl.g:992:1: ( 'genre' )
            {
            // InternalDsl.g:992:1: ( 'genre' )
            // InternalDsl.g:993:2: 'genre'
            {
             before(grammarAccess.getMultiplayerGameAccess().getGenreKeyword_4_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getGenreKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_4__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_4__1"
    // InternalDsl.g:1002:1: rule__MultiplayerGame__Group_4__1 : rule__MultiplayerGame__Group_4__1__Impl ;
    public final void rule__MultiplayerGame__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1006:1: ( rule__MultiplayerGame__Group_4__1__Impl )
            // InternalDsl.g:1007:2: rule__MultiplayerGame__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_4__1"


    // $ANTLR start "rule__MultiplayerGame__Group_4__1__Impl"
    // InternalDsl.g:1013:1: rule__MultiplayerGame__Group_4__1__Impl : ( ( rule__MultiplayerGame__GenreAssignment_4_1 ) ) ;
    public final void rule__MultiplayerGame__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1017:1: ( ( ( rule__MultiplayerGame__GenreAssignment_4_1 ) ) )
            // InternalDsl.g:1018:1: ( ( rule__MultiplayerGame__GenreAssignment_4_1 ) )
            {
            // InternalDsl.g:1018:1: ( ( rule__MultiplayerGame__GenreAssignment_4_1 ) )
            // InternalDsl.g:1019:2: ( rule__MultiplayerGame__GenreAssignment_4_1 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getGenreAssignment_4_1()); 
            // InternalDsl.g:1020:2: ( rule__MultiplayerGame__GenreAssignment_4_1 )
            // InternalDsl.g:1020:3: rule__MultiplayerGame__GenreAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__GenreAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getGenreAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_4__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_5__0"
    // InternalDsl.g:1029:1: rule__MultiplayerGame__Group_5__0 : rule__MultiplayerGame__Group_5__0__Impl rule__MultiplayerGame__Group_5__1 ;
    public final void rule__MultiplayerGame__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1033:1: ( rule__MultiplayerGame__Group_5__0__Impl rule__MultiplayerGame__Group_5__1 )
            // InternalDsl.g:1034:2: rule__MultiplayerGame__Group_5__0__Impl rule__MultiplayerGame__Group_5__1
            {
            pushFollow(FOLLOW_13);
            rule__MultiplayerGame__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_5__0"


    // $ANTLR start "rule__MultiplayerGame__Group_5__0__Impl"
    // InternalDsl.g:1041:1: rule__MultiplayerGame__Group_5__0__Impl : ( 'rating' ) ;
    public final void rule__MultiplayerGame__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1045:1: ( ( 'rating' ) )
            // InternalDsl.g:1046:1: ( 'rating' )
            {
            // InternalDsl.g:1046:1: ( 'rating' )
            // InternalDsl.g:1047:2: 'rating'
            {
             before(grammarAccess.getMultiplayerGameAccess().getRatingKeyword_5_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getRatingKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_5__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_5__1"
    // InternalDsl.g:1056:1: rule__MultiplayerGame__Group_5__1 : rule__MultiplayerGame__Group_5__1__Impl ;
    public final void rule__MultiplayerGame__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1060:1: ( rule__MultiplayerGame__Group_5__1__Impl )
            // InternalDsl.g:1061:2: rule__MultiplayerGame__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_5__1"


    // $ANTLR start "rule__MultiplayerGame__Group_5__1__Impl"
    // InternalDsl.g:1067:1: rule__MultiplayerGame__Group_5__1__Impl : ( ( rule__MultiplayerGame__RatingAssignment_5_1 ) ) ;
    public final void rule__MultiplayerGame__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1071:1: ( ( ( rule__MultiplayerGame__RatingAssignment_5_1 ) ) )
            // InternalDsl.g:1072:1: ( ( rule__MultiplayerGame__RatingAssignment_5_1 ) )
            {
            // InternalDsl.g:1072:1: ( ( rule__MultiplayerGame__RatingAssignment_5_1 ) )
            // InternalDsl.g:1073:2: ( rule__MultiplayerGame__RatingAssignment_5_1 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getRatingAssignment_5_1()); 
            // InternalDsl.g:1074:2: ( rule__MultiplayerGame__RatingAssignment_5_1 )
            // InternalDsl.g:1074:3: rule__MultiplayerGame__RatingAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__RatingAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getRatingAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_5__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_6__0"
    // InternalDsl.g:1083:1: rule__MultiplayerGame__Group_6__0 : rule__MultiplayerGame__Group_6__0__Impl rule__MultiplayerGame__Group_6__1 ;
    public final void rule__MultiplayerGame__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1087:1: ( rule__MultiplayerGame__Group_6__0__Impl rule__MultiplayerGame__Group_6__1 )
            // InternalDsl.g:1088:2: rule__MultiplayerGame__Group_6__0__Impl rule__MultiplayerGame__Group_6__1
            {
            pushFollow(FOLLOW_14);
            rule__MultiplayerGame__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_6__0"


    // $ANTLR start "rule__MultiplayerGame__Group_6__0__Impl"
    // InternalDsl.g:1095:1: rule__MultiplayerGame__Group_6__0__Impl : ( 'releaseDate' ) ;
    public final void rule__MultiplayerGame__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1099:1: ( ( 'releaseDate' ) )
            // InternalDsl.g:1100:1: ( 'releaseDate' )
            {
            // InternalDsl.g:1100:1: ( 'releaseDate' )
            // InternalDsl.g:1101:2: 'releaseDate'
            {
             before(grammarAccess.getMultiplayerGameAccess().getReleaseDateKeyword_6_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getReleaseDateKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_6__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_6__1"
    // InternalDsl.g:1110:1: rule__MultiplayerGame__Group_6__1 : rule__MultiplayerGame__Group_6__1__Impl ;
    public final void rule__MultiplayerGame__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1114:1: ( rule__MultiplayerGame__Group_6__1__Impl )
            // InternalDsl.g:1115:2: rule__MultiplayerGame__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_6__1"


    // $ANTLR start "rule__MultiplayerGame__Group_6__1__Impl"
    // InternalDsl.g:1121:1: rule__MultiplayerGame__Group_6__1__Impl : ( ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 ) ) ;
    public final void rule__MultiplayerGame__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1125:1: ( ( ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 ) ) )
            // InternalDsl.g:1126:1: ( ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 ) )
            {
            // InternalDsl.g:1126:1: ( ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 ) )
            // InternalDsl.g:1127:2: ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getReleaseDateAssignment_6_1()); 
            // InternalDsl.g:1128:2: ( rule__MultiplayerGame__ReleaseDateAssignment_6_1 )
            // InternalDsl.g:1128:3: rule__MultiplayerGame__ReleaseDateAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__ReleaseDateAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getReleaseDateAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_6__1__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_7__0"
    // InternalDsl.g:1137:1: rule__MultiplayerGame__Group_7__0 : rule__MultiplayerGame__Group_7__0__Impl rule__MultiplayerGame__Group_7__1 ;
    public final void rule__MultiplayerGame__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1141:1: ( rule__MultiplayerGame__Group_7__0__Impl rule__MultiplayerGame__Group_7__1 )
            // InternalDsl.g:1142:2: rule__MultiplayerGame__Group_7__0__Impl rule__MultiplayerGame__Group_7__1
            {
            pushFollow(FOLLOW_13);
            rule__MultiplayerGame__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_7__0"


    // $ANTLR start "rule__MultiplayerGame__Group_7__0__Impl"
    // InternalDsl.g:1149:1: rule__MultiplayerGame__Group_7__0__Impl : ( 'maxPlayers' ) ;
    public final void rule__MultiplayerGame__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1153:1: ( ( 'maxPlayers' ) )
            // InternalDsl.g:1154:1: ( 'maxPlayers' )
            {
            // InternalDsl.g:1154:1: ( 'maxPlayers' )
            // InternalDsl.g:1155:2: 'maxPlayers'
            {
             before(grammarAccess.getMultiplayerGameAccess().getMaxPlayersKeyword_7_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getMultiplayerGameAccess().getMaxPlayersKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_7__0__Impl"


    // $ANTLR start "rule__MultiplayerGame__Group_7__1"
    // InternalDsl.g:1164:1: rule__MultiplayerGame__Group_7__1 : rule__MultiplayerGame__Group_7__1__Impl ;
    public final void rule__MultiplayerGame__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1168:1: ( rule__MultiplayerGame__Group_7__1__Impl )
            // InternalDsl.g:1169:2: rule__MultiplayerGame__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_7__1"


    // $ANTLR start "rule__MultiplayerGame__Group_7__1__Impl"
    // InternalDsl.g:1175:1: rule__MultiplayerGame__Group_7__1__Impl : ( ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 ) ) ;
    public final void rule__MultiplayerGame__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1179:1: ( ( ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 ) ) )
            // InternalDsl.g:1180:1: ( ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 ) )
            {
            // InternalDsl.g:1180:1: ( ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 ) )
            // InternalDsl.g:1181:2: ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 )
            {
             before(grammarAccess.getMultiplayerGameAccess().getMaxPlayersAssignment_7_1()); 
            // InternalDsl.g:1182:2: ( rule__MultiplayerGame__MaxPlayersAssignment_7_1 )
            // InternalDsl.g:1182:3: rule__MultiplayerGame__MaxPlayersAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__MultiplayerGame__MaxPlayersAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getMultiplayerGameAccess().getMaxPlayersAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__Group_7__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group__0"
    // InternalDsl.g:1191:1: rule__TournamentGame__Group__0 : rule__TournamentGame__Group__0__Impl rule__TournamentGame__Group__1 ;
    public final void rule__TournamentGame__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1195:1: ( rule__TournamentGame__Group__0__Impl rule__TournamentGame__Group__1 )
            // InternalDsl.g:1196:2: rule__TournamentGame__Group__0__Impl rule__TournamentGame__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__TournamentGame__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__0"


    // $ANTLR start "rule__TournamentGame__Group__0__Impl"
    // InternalDsl.g:1203:1: rule__TournamentGame__Group__0__Impl : ( () ) ;
    public final void rule__TournamentGame__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1207:1: ( ( () ) )
            // InternalDsl.g:1208:1: ( () )
            {
            // InternalDsl.g:1208:1: ( () )
            // InternalDsl.g:1209:2: ()
            {
             before(grammarAccess.getTournamentGameAccess().getTournamentGameAction_0()); 
            // InternalDsl.g:1210:2: ()
            // InternalDsl.g:1210:3: 
            {
            }

             after(grammarAccess.getTournamentGameAccess().getTournamentGameAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group__1"
    // InternalDsl.g:1218:1: rule__TournamentGame__Group__1 : rule__TournamentGame__Group__1__Impl rule__TournamentGame__Group__2 ;
    public final void rule__TournamentGame__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1222:1: ( rule__TournamentGame__Group__1__Impl rule__TournamentGame__Group__2 )
            // InternalDsl.g:1223:2: rule__TournamentGame__Group__1__Impl rule__TournamentGame__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__TournamentGame__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__1"


    // $ANTLR start "rule__TournamentGame__Group__1__Impl"
    // InternalDsl.g:1230:1: rule__TournamentGame__Group__1__Impl : ( 'TournamentGame' ) ;
    public final void rule__TournamentGame__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1234:1: ( ( 'TournamentGame' ) )
            // InternalDsl.g:1235:1: ( 'TournamentGame' )
            {
            // InternalDsl.g:1235:1: ( 'TournamentGame' )
            // InternalDsl.g:1236:2: 'TournamentGame'
            {
             before(grammarAccess.getTournamentGameAccess().getTournamentGameKeyword_1()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getTournamentGameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group__2"
    // InternalDsl.g:1245:1: rule__TournamentGame__Group__2 : rule__TournamentGame__Group__2__Impl rule__TournamentGame__Group__3 ;
    public final void rule__TournamentGame__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1249:1: ( rule__TournamentGame__Group__2__Impl rule__TournamentGame__Group__3 )
            // InternalDsl.g:1250:2: rule__TournamentGame__Group__2__Impl rule__TournamentGame__Group__3
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__2"


    // $ANTLR start "rule__TournamentGame__Group__2__Impl"
    // InternalDsl.g:1257:1: rule__TournamentGame__Group__2__Impl : ( '{' ) ;
    public final void rule__TournamentGame__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1261:1: ( ( '{' ) )
            // InternalDsl.g:1262:1: ( '{' )
            {
            // InternalDsl.g:1262:1: ( '{' )
            // InternalDsl.g:1263:2: '{'
            {
             before(grammarAccess.getTournamentGameAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__2__Impl"


    // $ANTLR start "rule__TournamentGame__Group__3"
    // InternalDsl.g:1272:1: rule__TournamentGame__Group__3 : rule__TournamentGame__Group__3__Impl rule__TournamentGame__Group__4 ;
    public final void rule__TournamentGame__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1276:1: ( rule__TournamentGame__Group__3__Impl rule__TournamentGame__Group__4 )
            // InternalDsl.g:1277:2: rule__TournamentGame__Group__3__Impl rule__TournamentGame__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__3"


    // $ANTLR start "rule__TournamentGame__Group__3__Impl"
    // InternalDsl.g:1284:1: rule__TournamentGame__Group__3__Impl : ( ( rule__TournamentGame__Group_3__0 )? ) ;
    public final void rule__TournamentGame__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1288:1: ( ( ( rule__TournamentGame__Group_3__0 )? ) )
            // InternalDsl.g:1289:1: ( ( rule__TournamentGame__Group_3__0 )? )
            {
            // InternalDsl.g:1289:1: ( ( rule__TournamentGame__Group_3__0 )? )
            // InternalDsl.g:1290:2: ( rule__TournamentGame__Group_3__0 )?
            {
             before(grammarAccess.getTournamentGameAccess().getGroup_3()); 
            // InternalDsl.g:1291:2: ( rule__TournamentGame__Group_3__0 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==19) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalDsl.g:1291:3: rule__TournamentGame__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TournamentGame__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTournamentGameAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__3__Impl"


    // $ANTLR start "rule__TournamentGame__Group__4"
    // InternalDsl.g:1299:1: rule__TournamentGame__Group__4 : rule__TournamentGame__Group__4__Impl rule__TournamentGame__Group__5 ;
    public final void rule__TournamentGame__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1303:1: ( rule__TournamentGame__Group__4__Impl rule__TournamentGame__Group__5 )
            // InternalDsl.g:1304:2: rule__TournamentGame__Group__4__Impl rule__TournamentGame__Group__5
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__4"


    // $ANTLR start "rule__TournamentGame__Group__4__Impl"
    // InternalDsl.g:1311:1: rule__TournamentGame__Group__4__Impl : ( ( rule__TournamentGame__Group_4__0 )? ) ;
    public final void rule__TournamentGame__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1315:1: ( ( ( rule__TournamentGame__Group_4__0 )? ) )
            // InternalDsl.g:1316:1: ( ( rule__TournamentGame__Group_4__0 )? )
            {
            // InternalDsl.g:1316:1: ( ( rule__TournamentGame__Group_4__0 )? )
            // InternalDsl.g:1317:2: ( rule__TournamentGame__Group_4__0 )?
            {
             before(grammarAccess.getTournamentGameAccess().getGroup_4()); 
            // InternalDsl.g:1318:2: ( rule__TournamentGame__Group_4__0 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==20) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalDsl.g:1318:3: rule__TournamentGame__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TournamentGame__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTournamentGameAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__4__Impl"


    // $ANTLR start "rule__TournamentGame__Group__5"
    // InternalDsl.g:1326:1: rule__TournamentGame__Group__5 : rule__TournamentGame__Group__5__Impl rule__TournamentGame__Group__6 ;
    public final void rule__TournamentGame__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1330:1: ( rule__TournamentGame__Group__5__Impl rule__TournamentGame__Group__6 )
            // InternalDsl.g:1331:2: rule__TournamentGame__Group__5__Impl rule__TournamentGame__Group__6
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__5"


    // $ANTLR start "rule__TournamentGame__Group__5__Impl"
    // InternalDsl.g:1338:1: rule__TournamentGame__Group__5__Impl : ( ( rule__TournamentGame__Group_5__0 )? ) ;
    public final void rule__TournamentGame__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1342:1: ( ( ( rule__TournamentGame__Group_5__0 )? ) )
            // InternalDsl.g:1343:1: ( ( rule__TournamentGame__Group_5__0 )? )
            {
            // InternalDsl.g:1343:1: ( ( rule__TournamentGame__Group_5__0 )? )
            // InternalDsl.g:1344:2: ( rule__TournamentGame__Group_5__0 )?
            {
             before(grammarAccess.getTournamentGameAccess().getGroup_5()); 
            // InternalDsl.g:1345:2: ( rule__TournamentGame__Group_5__0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==21) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalDsl.g:1345:3: rule__TournamentGame__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TournamentGame__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTournamentGameAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__5__Impl"


    // $ANTLR start "rule__TournamentGame__Group__6"
    // InternalDsl.g:1353:1: rule__TournamentGame__Group__6 : rule__TournamentGame__Group__6__Impl rule__TournamentGame__Group__7 ;
    public final void rule__TournamentGame__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1357:1: ( rule__TournamentGame__Group__6__Impl rule__TournamentGame__Group__7 )
            // InternalDsl.g:1358:2: rule__TournamentGame__Group__6__Impl rule__TournamentGame__Group__7
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__6"


    // $ANTLR start "rule__TournamentGame__Group__6__Impl"
    // InternalDsl.g:1365:1: rule__TournamentGame__Group__6__Impl : ( ( rule__TournamentGame__Group_6__0 )? ) ;
    public final void rule__TournamentGame__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1369:1: ( ( ( rule__TournamentGame__Group_6__0 )? ) )
            // InternalDsl.g:1370:1: ( ( rule__TournamentGame__Group_6__0 )? )
            {
            // InternalDsl.g:1370:1: ( ( rule__TournamentGame__Group_6__0 )? )
            // InternalDsl.g:1371:2: ( rule__TournamentGame__Group_6__0 )?
            {
             before(grammarAccess.getTournamentGameAccess().getGroup_6()); 
            // InternalDsl.g:1372:2: ( rule__TournamentGame__Group_6__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==22) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalDsl.g:1372:3: rule__TournamentGame__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TournamentGame__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTournamentGameAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__6__Impl"


    // $ANTLR start "rule__TournamentGame__Group__7"
    // InternalDsl.g:1380:1: rule__TournamentGame__Group__7 : rule__TournamentGame__Group__7__Impl rule__TournamentGame__Group__8 ;
    public final void rule__TournamentGame__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1384:1: ( rule__TournamentGame__Group__7__Impl rule__TournamentGame__Group__8 )
            // InternalDsl.g:1385:2: rule__TournamentGame__Group__7__Impl rule__TournamentGame__Group__8
            {
            pushFollow(FOLLOW_16);
            rule__TournamentGame__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__7"


    // $ANTLR start "rule__TournamentGame__Group__7__Impl"
    // InternalDsl.g:1392:1: rule__TournamentGame__Group__7__Impl : ( ( rule__TournamentGame__Group_7__0 )? ) ;
    public final void rule__TournamentGame__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1396:1: ( ( ( rule__TournamentGame__Group_7__0 )? ) )
            // InternalDsl.g:1397:1: ( ( rule__TournamentGame__Group_7__0 )? )
            {
            // InternalDsl.g:1397:1: ( ( rule__TournamentGame__Group_7__0 )? )
            // InternalDsl.g:1398:2: ( rule__TournamentGame__Group_7__0 )?
            {
             before(grammarAccess.getTournamentGameAccess().getGroup_7()); 
            // InternalDsl.g:1399:2: ( rule__TournamentGame__Group_7__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==25) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalDsl.g:1399:3: rule__TournamentGame__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__TournamentGame__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTournamentGameAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__7__Impl"


    // $ANTLR start "rule__TournamentGame__Group__8"
    // InternalDsl.g:1407:1: rule__TournamentGame__Group__8 : rule__TournamentGame__Group__8__Impl ;
    public final void rule__TournamentGame__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1411:1: ( rule__TournamentGame__Group__8__Impl )
            // InternalDsl.g:1412:2: rule__TournamentGame__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__8"


    // $ANTLR start "rule__TournamentGame__Group__8__Impl"
    // InternalDsl.g:1418:1: rule__TournamentGame__Group__8__Impl : ( '}' ) ;
    public final void rule__TournamentGame__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1422:1: ( ( '}' ) )
            // InternalDsl.g:1423:1: ( '}' )
            {
            // InternalDsl.g:1423:1: ( '}' )
            // InternalDsl.g:1424:2: '}'
            {
             before(grammarAccess.getTournamentGameAccess().getRightCurlyBracketKeyword_8()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group__8__Impl"


    // $ANTLR start "rule__TournamentGame__Group_3__0"
    // InternalDsl.g:1434:1: rule__TournamentGame__Group_3__0 : rule__TournamentGame__Group_3__0__Impl rule__TournamentGame__Group_3__1 ;
    public final void rule__TournamentGame__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1438:1: ( rule__TournamentGame__Group_3__0__Impl rule__TournamentGame__Group_3__1 )
            // InternalDsl.g:1439:2: rule__TournamentGame__Group_3__0__Impl rule__TournamentGame__Group_3__1
            {
            pushFollow(FOLLOW_12);
            rule__TournamentGame__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_3__0"


    // $ANTLR start "rule__TournamentGame__Group_3__0__Impl"
    // InternalDsl.g:1446:1: rule__TournamentGame__Group_3__0__Impl : ( 'title' ) ;
    public final void rule__TournamentGame__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1450:1: ( ( 'title' ) )
            // InternalDsl.g:1451:1: ( 'title' )
            {
            // InternalDsl.g:1451:1: ( 'title' )
            // InternalDsl.g:1452:2: 'title'
            {
             before(grammarAccess.getTournamentGameAccess().getTitleKeyword_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getTitleKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_3__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group_3__1"
    // InternalDsl.g:1461:1: rule__TournamentGame__Group_3__1 : rule__TournamentGame__Group_3__1__Impl ;
    public final void rule__TournamentGame__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1465:1: ( rule__TournamentGame__Group_3__1__Impl )
            // InternalDsl.g:1466:2: rule__TournamentGame__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_3__1"


    // $ANTLR start "rule__TournamentGame__Group_3__1__Impl"
    // InternalDsl.g:1472:1: rule__TournamentGame__Group_3__1__Impl : ( ( rule__TournamentGame__TitleAssignment_3_1 ) ) ;
    public final void rule__TournamentGame__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1476:1: ( ( ( rule__TournamentGame__TitleAssignment_3_1 ) ) )
            // InternalDsl.g:1477:1: ( ( rule__TournamentGame__TitleAssignment_3_1 ) )
            {
            // InternalDsl.g:1477:1: ( ( rule__TournamentGame__TitleAssignment_3_1 ) )
            // InternalDsl.g:1478:2: ( rule__TournamentGame__TitleAssignment_3_1 )
            {
             before(grammarAccess.getTournamentGameAccess().getTitleAssignment_3_1()); 
            // InternalDsl.g:1479:2: ( rule__TournamentGame__TitleAssignment_3_1 )
            // InternalDsl.g:1479:3: rule__TournamentGame__TitleAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__TitleAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getTitleAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_3__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group_4__0"
    // InternalDsl.g:1488:1: rule__TournamentGame__Group_4__0 : rule__TournamentGame__Group_4__0__Impl rule__TournamentGame__Group_4__1 ;
    public final void rule__TournamentGame__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1492:1: ( rule__TournamentGame__Group_4__0__Impl rule__TournamentGame__Group_4__1 )
            // InternalDsl.g:1493:2: rule__TournamentGame__Group_4__0__Impl rule__TournamentGame__Group_4__1
            {
            pushFollow(FOLLOW_12);
            rule__TournamentGame__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_4__0"


    // $ANTLR start "rule__TournamentGame__Group_4__0__Impl"
    // InternalDsl.g:1500:1: rule__TournamentGame__Group_4__0__Impl : ( 'genre' ) ;
    public final void rule__TournamentGame__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1504:1: ( ( 'genre' ) )
            // InternalDsl.g:1505:1: ( 'genre' )
            {
            // InternalDsl.g:1505:1: ( 'genre' )
            // InternalDsl.g:1506:2: 'genre'
            {
             before(grammarAccess.getTournamentGameAccess().getGenreKeyword_4_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getGenreKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_4__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group_4__1"
    // InternalDsl.g:1515:1: rule__TournamentGame__Group_4__1 : rule__TournamentGame__Group_4__1__Impl ;
    public final void rule__TournamentGame__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1519:1: ( rule__TournamentGame__Group_4__1__Impl )
            // InternalDsl.g:1520:2: rule__TournamentGame__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_4__1"


    // $ANTLR start "rule__TournamentGame__Group_4__1__Impl"
    // InternalDsl.g:1526:1: rule__TournamentGame__Group_4__1__Impl : ( ( rule__TournamentGame__GenreAssignment_4_1 ) ) ;
    public final void rule__TournamentGame__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1530:1: ( ( ( rule__TournamentGame__GenreAssignment_4_1 ) ) )
            // InternalDsl.g:1531:1: ( ( rule__TournamentGame__GenreAssignment_4_1 ) )
            {
            // InternalDsl.g:1531:1: ( ( rule__TournamentGame__GenreAssignment_4_1 ) )
            // InternalDsl.g:1532:2: ( rule__TournamentGame__GenreAssignment_4_1 )
            {
             before(grammarAccess.getTournamentGameAccess().getGenreAssignment_4_1()); 
            // InternalDsl.g:1533:2: ( rule__TournamentGame__GenreAssignment_4_1 )
            // InternalDsl.g:1533:3: rule__TournamentGame__GenreAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__GenreAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getGenreAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_4__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group_5__0"
    // InternalDsl.g:1542:1: rule__TournamentGame__Group_5__0 : rule__TournamentGame__Group_5__0__Impl rule__TournamentGame__Group_5__1 ;
    public final void rule__TournamentGame__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1546:1: ( rule__TournamentGame__Group_5__0__Impl rule__TournamentGame__Group_5__1 )
            // InternalDsl.g:1547:2: rule__TournamentGame__Group_5__0__Impl rule__TournamentGame__Group_5__1
            {
            pushFollow(FOLLOW_13);
            rule__TournamentGame__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_5__0"


    // $ANTLR start "rule__TournamentGame__Group_5__0__Impl"
    // InternalDsl.g:1554:1: rule__TournamentGame__Group_5__0__Impl : ( 'rating' ) ;
    public final void rule__TournamentGame__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1558:1: ( ( 'rating' ) )
            // InternalDsl.g:1559:1: ( 'rating' )
            {
            // InternalDsl.g:1559:1: ( 'rating' )
            // InternalDsl.g:1560:2: 'rating'
            {
             before(grammarAccess.getTournamentGameAccess().getRatingKeyword_5_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getRatingKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_5__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group_5__1"
    // InternalDsl.g:1569:1: rule__TournamentGame__Group_5__1 : rule__TournamentGame__Group_5__1__Impl ;
    public final void rule__TournamentGame__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1573:1: ( rule__TournamentGame__Group_5__1__Impl )
            // InternalDsl.g:1574:2: rule__TournamentGame__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_5__1"


    // $ANTLR start "rule__TournamentGame__Group_5__1__Impl"
    // InternalDsl.g:1580:1: rule__TournamentGame__Group_5__1__Impl : ( ( rule__TournamentGame__RatingAssignment_5_1 ) ) ;
    public final void rule__TournamentGame__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1584:1: ( ( ( rule__TournamentGame__RatingAssignment_5_1 ) ) )
            // InternalDsl.g:1585:1: ( ( rule__TournamentGame__RatingAssignment_5_1 ) )
            {
            // InternalDsl.g:1585:1: ( ( rule__TournamentGame__RatingAssignment_5_1 ) )
            // InternalDsl.g:1586:2: ( rule__TournamentGame__RatingAssignment_5_1 )
            {
             before(grammarAccess.getTournamentGameAccess().getRatingAssignment_5_1()); 
            // InternalDsl.g:1587:2: ( rule__TournamentGame__RatingAssignment_5_1 )
            // InternalDsl.g:1587:3: rule__TournamentGame__RatingAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__RatingAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getRatingAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_5__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group_6__0"
    // InternalDsl.g:1596:1: rule__TournamentGame__Group_6__0 : rule__TournamentGame__Group_6__0__Impl rule__TournamentGame__Group_6__1 ;
    public final void rule__TournamentGame__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1600:1: ( rule__TournamentGame__Group_6__0__Impl rule__TournamentGame__Group_6__1 )
            // InternalDsl.g:1601:2: rule__TournamentGame__Group_6__0__Impl rule__TournamentGame__Group_6__1
            {
            pushFollow(FOLLOW_14);
            rule__TournamentGame__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_6__0"


    // $ANTLR start "rule__TournamentGame__Group_6__0__Impl"
    // InternalDsl.g:1608:1: rule__TournamentGame__Group_6__0__Impl : ( 'releaseDate' ) ;
    public final void rule__TournamentGame__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1612:1: ( ( 'releaseDate' ) )
            // InternalDsl.g:1613:1: ( 'releaseDate' )
            {
            // InternalDsl.g:1613:1: ( 'releaseDate' )
            // InternalDsl.g:1614:2: 'releaseDate'
            {
             before(grammarAccess.getTournamentGameAccess().getReleaseDateKeyword_6_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getReleaseDateKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_6__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group_6__1"
    // InternalDsl.g:1623:1: rule__TournamentGame__Group_6__1 : rule__TournamentGame__Group_6__1__Impl ;
    public final void rule__TournamentGame__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1627:1: ( rule__TournamentGame__Group_6__1__Impl )
            // InternalDsl.g:1628:2: rule__TournamentGame__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_6__1"


    // $ANTLR start "rule__TournamentGame__Group_6__1__Impl"
    // InternalDsl.g:1634:1: rule__TournamentGame__Group_6__1__Impl : ( ( rule__TournamentGame__ReleaseDateAssignment_6_1 ) ) ;
    public final void rule__TournamentGame__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1638:1: ( ( ( rule__TournamentGame__ReleaseDateAssignment_6_1 ) ) )
            // InternalDsl.g:1639:1: ( ( rule__TournamentGame__ReleaseDateAssignment_6_1 ) )
            {
            // InternalDsl.g:1639:1: ( ( rule__TournamentGame__ReleaseDateAssignment_6_1 ) )
            // InternalDsl.g:1640:2: ( rule__TournamentGame__ReleaseDateAssignment_6_1 )
            {
             before(grammarAccess.getTournamentGameAccess().getReleaseDateAssignment_6_1()); 
            // InternalDsl.g:1641:2: ( rule__TournamentGame__ReleaseDateAssignment_6_1 )
            // InternalDsl.g:1641:3: rule__TournamentGame__ReleaseDateAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__ReleaseDateAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getReleaseDateAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_6__1__Impl"


    // $ANTLR start "rule__TournamentGame__Group_7__0"
    // InternalDsl.g:1650:1: rule__TournamentGame__Group_7__0 : rule__TournamentGame__Group_7__0__Impl rule__TournamentGame__Group_7__1 ;
    public final void rule__TournamentGame__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1654:1: ( rule__TournamentGame__Group_7__0__Impl rule__TournamentGame__Group_7__1 )
            // InternalDsl.g:1655:2: rule__TournamentGame__Group_7__0__Impl rule__TournamentGame__Group_7__1
            {
            pushFollow(FOLLOW_12);
            rule__TournamentGame__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_7__0"


    // $ANTLR start "rule__TournamentGame__Group_7__0__Impl"
    // InternalDsl.g:1662:1: rule__TournamentGame__Group_7__0__Impl : ( 'tournamentFormat' ) ;
    public final void rule__TournamentGame__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1666:1: ( ( 'tournamentFormat' ) )
            // InternalDsl.g:1667:1: ( 'tournamentFormat' )
            {
            // InternalDsl.g:1667:1: ( 'tournamentFormat' )
            // InternalDsl.g:1668:2: 'tournamentFormat'
            {
             before(grammarAccess.getTournamentGameAccess().getTournamentFormatKeyword_7_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getTournamentGameAccess().getTournamentFormatKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_7__0__Impl"


    // $ANTLR start "rule__TournamentGame__Group_7__1"
    // InternalDsl.g:1677:1: rule__TournamentGame__Group_7__1 : rule__TournamentGame__Group_7__1__Impl ;
    public final void rule__TournamentGame__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1681:1: ( rule__TournamentGame__Group_7__1__Impl )
            // InternalDsl.g:1682:2: rule__TournamentGame__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_7__1"


    // $ANTLR start "rule__TournamentGame__Group_7__1__Impl"
    // InternalDsl.g:1688:1: rule__TournamentGame__Group_7__1__Impl : ( ( rule__TournamentGame__TournamentFormatAssignment_7_1 ) ) ;
    public final void rule__TournamentGame__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1692:1: ( ( ( rule__TournamentGame__TournamentFormatAssignment_7_1 ) ) )
            // InternalDsl.g:1693:1: ( ( rule__TournamentGame__TournamentFormatAssignment_7_1 ) )
            {
            // InternalDsl.g:1693:1: ( ( rule__TournamentGame__TournamentFormatAssignment_7_1 ) )
            // InternalDsl.g:1694:2: ( rule__TournamentGame__TournamentFormatAssignment_7_1 )
            {
             before(grammarAccess.getTournamentGameAccess().getTournamentFormatAssignment_7_1()); 
            // InternalDsl.g:1695:2: ( rule__TournamentGame__TournamentFormatAssignment_7_1 )
            // InternalDsl.g:1695:3: rule__TournamentGame__TournamentFormatAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__TournamentGame__TournamentFormatAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getTournamentGameAccess().getTournamentFormatAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__Group_7__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__0"
    // InternalDsl.g:1704:1: rule__SinglePlayerGame__Group__0 : rule__SinglePlayerGame__Group__0__Impl rule__SinglePlayerGame__Group__1 ;
    public final void rule__SinglePlayerGame__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1708:1: ( rule__SinglePlayerGame__Group__0__Impl rule__SinglePlayerGame__Group__1 )
            // InternalDsl.g:1709:2: rule__SinglePlayerGame__Group__0__Impl rule__SinglePlayerGame__Group__1
            {
            pushFollow(FOLLOW_6);
            rule__SinglePlayerGame__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__0"


    // $ANTLR start "rule__SinglePlayerGame__Group__0__Impl"
    // InternalDsl.g:1716:1: rule__SinglePlayerGame__Group__0__Impl : ( () ) ;
    public final void rule__SinglePlayerGame__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1720:1: ( ( () ) )
            // InternalDsl.g:1721:1: ( () )
            {
            // InternalDsl.g:1721:1: ( () )
            // InternalDsl.g:1722:2: ()
            {
             before(grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameAction_0()); 
            // InternalDsl.g:1723:2: ()
            // InternalDsl.g:1723:3: 
            {
            }

             after(grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__1"
    // InternalDsl.g:1731:1: rule__SinglePlayerGame__Group__1 : rule__SinglePlayerGame__Group__1__Impl rule__SinglePlayerGame__Group__2 ;
    public final void rule__SinglePlayerGame__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1735:1: ( rule__SinglePlayerGame__Group__1__Impl rule__SinglePlayerGame__Group__2 )
            // InternalDsl.g:1736:2: rule__SinglePlayerGame__Group__1__Impl rule__SinglePlayerGame__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SinglePlayerGame__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__1"


    // $ANTLR start "rule__SinglePlayerGame__Group__1__Impl"
    // InternalDsl.g:1743:1: rule__SinglePlayerGame__Group__1__Impl : ( 'SinglePlayerGame' ) ;
    public final void rule__SinglePlayerGame__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1747:1: ( ( 'SinglePlayerGame' ) )
            // InternalDsl.g:1748:1: ( 'SinglePlayerGame' )
            {
            // InternalDsl.g:1748:1: ( 'SinglePlayerGame' )
            // InternalDsl.g:1749:2: 'SinglePlayerGame'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameKeyword_1()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getSinglePlayerGameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__2"
    // InternalDsl.g:1758:1: rule__SinglePlayerGame__Group__2 : rule__SinglePlayerGame__Group__2__Impl rule__SinglePlayerGame__Group__3 ;
    public final void rule__SinglePlayerGame__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1762:1: ( rule__SinglePlayerGame__Group__2__Impl rule__SinglePlayerGame__Group__3 )
            // InternalDsl.g:1763:2: rule__SinglePlayerGame__Group__2__Impl rule__SinglePlayerGame__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__2"


    // $ANTLR start "rule__SinglePlayerGame__Group__2__Impl"
    // InternalDsl.g:1770:1: rule__SinglePlayerGame__Group__2__Impl : ( '{' ) ;
    public final void rule__SinglePlayerGame__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1774:1: ( ( '{' ) )
            // InternalDsl.g:1775:1: ( '{' )
            {
            // InternalDsl.g:1775:1: ( '{' )
            // InternalDsl.g:1776:2: '{'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__2__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__3"
    // InternalDsl.g:1785:1: rule__SinglePlayerGame__Group__3 : rule__SinglePlayerGame__Group__3__Impl rule__SinglePlayerGame__Group__4 ;
    public final void rule__SinglePlayerGame__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1789:1: ( rule__SinglePlayerGame__Group__3__Impl rule__SinglePlayerGame__Group__4 )
            // InternalDsl.g:1790:2: rule__SinglePlayerGame__Group__3__Impl rule__SinglePlayerGame__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__3"


    // $ANTLR start "rule__SinglePlayerGame__Group__3__Impl"
    // InternalDsl.g:1797:1: rule__SinglePlayerGame__Group__3__Impl : ( ( rule__SinglePlayerGame__Group_3__0 )? ) ;
    public final void rule__SinglePlayerGame__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1801:1: ( ( ( rule__SinglePlayerGame__Group_3__0 )? ) )
            // InternalDsl.g:1802:1: ( ( rule__SinglePlayerGame__Group_3__0 )? )
            {
            // InternalDsl.g:1802:1: ( ( rule__SinglePlayerGame__Group_3__0 )? )
            // InternalDsl.g:1803:2: ( rule__SinglePlayerGame__Group_3__0 )?
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup_3()); 
            // InternalDsl.g:1804:2: ( rule__SinglePlayerGame__Group_3__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==19) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalDsl.g:1804:3: rule__SinglePlayerGame__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SinglePlayerGame__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__3__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__4"
    // InternalDsl.g:1812:1: rule__SinglePlayerGame__Group__4 : rule__SinglePlayerGame__Group__4__Impl rule__SinglePlayerGame__Group__5 ;
    public final void rule__SinglePlayerGame__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1816:1: ( rule__SinglePlayerGame__Group__4__Impl rule__SinglePlayerGame__Group__5 )
            // InternalDsl.g:1817:2: rule__SinglePlayerGame__Group__4__Impl rule__SinglePlayerGame__Group__5
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__4"


    // $ANTLR start "rule__SinglePlayerGame__Group__4__Impl"
    // InternalDsl.g:1824:1: rule__SinglePlayerGame__Group__4__Impl : ( ( rule__SinglePlayerGame__Group_4__0 )? ) ;
    public final void rule__SinglePlayerGame__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1828:1: ( ( ( rule__SinglePlayerGame__Group_4__0 )? ) )
            // InternalDsl.g:1829:1: ( ( rule__SinglePlayerGame__Group_4__0 )? )
            {
            // InternalDsl.g:1829:1: ( ( rule__SinglePlayerGame__Group_4__0 )? )
            // InternalDsl.g:1830:2: ( rule__SinglePlayerGame__Group_4__0 )?
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup_4()); 
            // InternalDsl.g:1831:2: ( rule__SinglePlayerGame__Group_4__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==20) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalDsl.g:1831:3: rule__SinglePlayerGame__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SinglePlayerGame__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__4__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__5"
    // InternalDsl.g:1839:1: rule__SinglePlayerGame__Group__5 : rule__SinglePlayerGame__Group__5__Impl rule__SinglePlayerGame__Group__6 ;
    public final void rule__SinglePlayerGame__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1843:1: ( rule__SinglePlayerGame__Group__5__Impl rule__SinglePlayerGame__Group__6 )
            // InternalDsl.g:1844:2: rule__SinglePlayerGame__Group__5__Impl rule__SinglePlayerGame__Group__6
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__5"


    // $ANTLR start "rule__SinglePlayerGame__Group__5__Impl"
    // InternalDsl.g:1851:1: rule__SinglePlayerGame__Group__5__Impl : ( ( rule__SinglePlayerGame__Group_5__0 )? ) ;
    public final void rule__SinglePlayerGame__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1855:1: ( ( ( rule__SinglePlayerGame__Group_5__0 )? ) )
            // InternalDsl.g:1856:1: ( ( rule__SinglePlayerGame__Group_5__0 )? )
            {
            // InternalDsl.g:1856:1: ( ( rule__SinglePlayerGame__Group_5__0 )? )
            // InternalDsl.g:1857:2: ( rule__SinglePlayerGame__Group_5__0 )?
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup_5()); 
            // InternalDsl.g:1858:2: ( rule__SinglePlayerGame__Group_5__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==21) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalDsl.g:1858:3: rule__SinglePlayerGame__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SinglePlayerGame__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__5__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__6"
    // InternalDsl.g:1866:1: rule__SinglePlayerGame__Group__6 : rule__SinglePlayerGame__Group__6__Impl rule__SinglePlayerGame__Group__7 ;
    public final void rule__SinglePlayerGame__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1870:1: ( rule__SinglePlayerGame__Group__6__Impl rule__SinglePlayerGame__Group__7 )
            // InternalDsl.g:1871:2: rule__SinglePlayerGame__Group__6__Impl rule__SinglePlayerGame__Group__7
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__6"


    // $ANTLR start "rule__SinglePlayerGame__Group__6__Impl"
    // InternalDsl.g:1878:1: rule__SinglePlayerGame__Group__6__Impl : ( ( rule__SinglePlayerGame__Group_6__0 )? ) ;
    public final void rule__SinglePlayerGame__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1882:1: ( ( ( rule__SinglePlayerGame__Group_6__0 )? ) )
            // InternalDsl.g:1883:1: ( ( rule__SinglePlayerGame__Group_6__0 )? )
            {
            // InternalDsl.g:1883:1: ( ( rule__SinglePlayerGame__Group_6__0 )? )
            // InternalDsl.g:1884:2: ( rule__SinglePlayerGame__Group_6__0 )?
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup_6()); 
            // InternalDsl.g:1885:2: ( rule__SinglePlayerGame__Group_6__0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==22) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalDsl.g:1885:3: rule__SinglePlayerGame__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SinglePlayerGame__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__6__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__7"
    // InternalDsl.g:1893:1: rule__SinglePlayerGame__Group__7 : rule__SinglePlayerGame__Group__7__Impl rule__SinglePlayerGame__Group__8 ;
    public final void rule__SinglePlayerGame__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1897:1: ( rule__SinglePlayerGame__Group__7__Impl rule__SinglePlayerGame__Group__8 )
            // InternalDsl.g:1898:2: rule__SinglePlayerGame__Group__7__Impl rule__SinglePlayerGame__Group__8
            {
            pushFollow(FOLLOW_17);
            rule__SinglePlayerGame__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__7"


    // $ANTLR start "rule__SinglePlayerGame__Group__7__Impl"
    // InternalDsl.g:1905:1: rule__SinglePlayerGame__Group__7__Impl : ( ( rule__SinglePlayerGame__Group_7__0 )? ) ;
    public final void rule__SinglePlayerGame__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1909:1: ( ( ( rule__SinglePlayerGame__Group_7__0 )? ) )
            // InternalDsl.g:1910:1: ( ( rule__SinglePlayerGame__Group_7__0 )? )
            {
            // InternalDsl.g:1910:1: ( ( rule__SinglePlayerGame__Group_7__0 )? )
            // InternalDsl.g:1911:2: ( rule__SinglePlayerGame__Group_7__0 )?
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGroup_7()); 
            // InternalDsl.g:1912:2: ( rule__SinglePlayerGame__Group_7__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==27) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalDsl.g:1912:3: rule__SinglePlayerGame__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SinglePlayerGame__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSinglePlayerGameAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__7__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group__8"
    // InternalDsl.g:1920:1: rule__SinglePlayerGame__Group__8 : rule__SinglePlayerGame__Group__8__Impl ;
    public final void rule__SinglePlayerGame__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1924:1: ( rule__SinglePlayerGame__Group__8__Impl )
            // InternalDsl.g:1925:2: rule__SinglePlayerGame__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__8"


    // $ANTLR start "rule__SinglePlayerGame__Group__8__Impl"
    // InternalDsl.g:1931:1: rule__SinglePlayerGame__Group__8__Impl : ( '}' ) ;
    public final void rule__SinglePlayerGame__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1935:1: ( ( '}' ) )
            // InternalDsl.g:1936:1: ( '}' )
            {
            // InternalDsl.g:1936:1: ( '}' )
            // InternalDsl.g:1937:2: '}'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getRightCurlyBracketKeyword_8()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group__8__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_3__0"
    // InternalDsl.g:1947:1: rule__SinglePlayerGame__Group_3__0 : rule__SinglePlayerGame__Group_3__0__Impl rule__SinglePlayerGame__Group_3__1 ;
    public final void rule__SinglePlayerGame__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1951:1: ( rule__SinglePlayerGame__Group_3__0__Impl rule__SinglePlayerGame__Group_3__1 )
            // InternalDsl.g:1952:2: rule__SinglePlayerGame__Group_3__0__Impl rule__SinglePlayerGame__Group_3__1
            {
            pushFollow(FOLLOW_12);
            rule__SinglePlayerGame__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_3__0"


    // $ANTLR start "rule__SinglePlayerGame__Group_3__0__Impl"
    // InternalDsl.g:1959:1: rule__SinglePlayerGame__Group_3__0__Impl : ( 'title' ) ;
    public final void rule__SinglePlayerGame__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1963:1: ( ( 'title' ) )
            // InternalDsl.g:1964:1: ( 'title' )
            {
            // InternalDsl.g:1964:1: ( 'title' )
            // InternalDsl.g:1965:2: 'title'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getTitleKeyword_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getTitleKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_3__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_3__1"
    // InternalDsl.g:1974:1: rule__SinglePlayerGame__Group_3__1 : rule__SinglePlayerGame__Group_3__1__Impl ;
    public final void rule__SinglePlayerGame__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1978:1: ( rule__SinglePlayerGame__Group_3__1__Impl )
            // InternalDsl.g:1979:2: rule__SinglePlayerGame__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_3__1"


    // $ANTLR start "rule__SinglePlayerGame__Group_3__1__Impl"
    // InternalDsl.g:1985:1: rule__SinglePlayerGame__Group_3__1__Impl : ( ( rule__SinglePlayerGame__TitleAssignment_3_1 ) ) ;
    public final void rule__SinglePlayerGame__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1989:1: ( ( ( rule__SinglePlayerGame__TitleAssignment_3_1 ) ) )
            // InternalDsl.g:1990:1: ( ( rule__SinglePlayerGame__TitleAssignment_3_1 ) )
            {
            // InternalDsl.g:1990:1: ( ( rule__SinglePlayerGame__TitleAssignment_3_1 ) )
            // InternalDsl.g:1991:2: ( rule__SinglePlayerGame__TitleAssignment_3_1 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getTitleAssignment_3_1()); 
            // InternalDsl.g:1992:2: ( rule__SinglePlayerGame__TitleAssignment_3_1 )
            // InternalDsl.g:1992:3: rule__SinglePlayerGame__TitleAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__TitleAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getTitleAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_3__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_4__0"
    // InternalDsl.g:2001:1: rule__SinglePlayerGame__Group_4__0 : rule__SinglePlayerGame__Group_4__0__Impl rule__SinglePlayerGame__Group_4__1 ;
    public final void rule__SinglePlayerGame__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2005:1: ( rule__SinglePlayerGame__Group_4__0__Impl rule__SinglePlayerGame__Group_4__1 )
            // InternalDsl.g:2006:2: rule__SinglePlayerGame__Group_4__0__Impl rule__SinglePlayerGame__Group_4__1
            {
            pushFollow(FOLLOW_12);
            rule__SinglePlayerGame__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_4__0"


    // $ANTLR start "rule__SinglePlayerGame__Group_4__0__Impl"
    // InternalDsl.g:2013:1: rule__SinglePlayerGame__Group_4__0__Impl : ( 'genre' ) ;
    public final void rule__SinglePlayerGame__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2017:1: ( ( 'genre' ) )
            // InternalDsl.g:2018:1: ( 'genre' )
            {
            // InternalDsl.g:2018:1: ( 'genre' )
            // InternalDsl.g:2019:2: 'genre'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGenreKeyword_4_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getGenreKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_4__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_4__1"
    // InternalDsl.g:2028:1: rule__SinglePlayerGame__Group_4__1 : rule__SinglePlayerGame__Group_4__1__Impl ;
    public final void rule__SinglePlayerGame__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2032:1: ( rule__SinglePlayerGame__Group_4__1__Impl )
            // InternalDsl.g:2033:2: rule__SinglePlayerGame__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_4__1"


    // $ANTLR start "rule__SinglePlayerGame__Group_4__1__Impl"
    // InternalDsl.g:2039:1: rule__SinglePlayerGame__Group_4__1__Impl : ( ( rule__SinglePlayerGame__GenreAssignment_4_1 ) ) ;
    public final void rule__SinglePlayerGame__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2043:1: ( ( ( rule__SinglePlayerGame__GenreAssignment_4_1 ) ) )
            // InternalDsl.g:2044:1: ( ( rule__SinglePlayerGame__GenreAssignment_4_1 ) )
            {
            // InternalDsl.g:2044:1: ( ( rule__SinglePlayerGame__GenreAssignment_4_1 ) )
            // InternalDsl.g:2045:2: ( rule__SinglePlayerGame__GenreAssignment_4_1 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGenreAssignment_4_1()); 
            // InternalDsl.g:2046:2: ( rule__SinglePlayerGame__GenreAssignment_4_1 )
            // InternalDsl.g:2046:3: rule__SinglePlayerGame__GenreAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__GenreAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getGenreAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_4__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_5__0"
    // InternalDsl.g:2055:1: rule__SinglePlayerGame__Group_5__0 : rule__SinglePlayerGame__Group_5__0__Impl rule__SinglePlayerGame__Group_5__1 ;
    public final void rule__SinglePlayerGame__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2059:1: ( rule__SinglePlayerGame__Group_5__0__Impl rule__SinglePlayerGame__Group_5__1 )
            // InternalDsl.g:2060:2: rule__SinglePlayerGame__Group_5__0__Impl rule__SinglePlayerGame__Group_5__1
            {
            pushFollow(FOLLOW_13);
            rule__SinglePlayerGame__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_5__0"


    // $ANTLR start "rule__SinglePlayerGame__Group_5__0__Impl"
    // InternalDsl.g:2067:1: rule__SinglePlayerGame__Group_5__0__Impl : ( 'rating' ) ;
    public final void rule__SinglePlayerGame__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2071:1: ( ( 'rating' ) )
            // InternalDsl.g:2072:1: ( 'rating' )
            {
            // InternalDsl.g:2072:1: ( 'rating' )
            // InternalDsl.g:2073:2: 'rating'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getRatingKeyword_5_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getRatingKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_5__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_5__1"
    // InternalDsl.g:2082:1: rule__SinglePlayerGame__Group_5__1 : rule__SinglePlayerGame__Group_5__1__Impl ;
    public final void rule__SinglePlayerGame__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2086:1: ( rule__SinglePlayerGame__Group_5__1__Impl )
            // InternalDsl.g:2087:2: rule__SinglePlayerGame__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_5__1"


    // $ANTLR start "rule__SinglePlayerGame__Group_5__1__Impl"
    // InternalDsl.g:2093:1: rule__SinglePlayerGame__Group_5__1__Impl : ( ( rule__SinglePlayerGame__RatingAssignment_5_1 ) ) ;
    public final void rule__SinglePlayerGame__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2097:1: ( ( ( rule__SinglePlayerGame__RatingAssignment_5_1 ) ) )
            // InternalDsl.g:2098:1: ( ( rule__SinglePlayerGame__RatingAssignment_5_1 ) )
            {
            // InternalDsl.g:2098:1: ( ( rule__SinglePlayerGame__RatingAssignment_5_1 ) )
            // InternalDsl.g:2099:2: ( rule__SinglePlayerGame__RatingAssignment_5_1 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getRatingAssignment_5_1()); 
            // InternalDsl.g:2100:2: ( rule__SinglePlayerGame__RatingAssignment_5_1 )
            // InternalDsl.g:2100:3: rule__SinglePlayerGame__RatingAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__RatingAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getRatingAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_5__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_6__0"
    // InternalDsl.g:2109:1: rule__SinglePlayerGame__Group_6__0 : rule__SinglePlayerGame__Group_6__0__Impl rule__SinglePlayerGame__Group_6__1 ;
    public final void rule__SinglePlayerGame__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2113:1: ( rule__SinglePlayerGame__Group_6__0__Impl rule__SinglePlayerGame__Group_6__1 )
            // InternalDsl.g:2114:2: rule__SinglePlayerGame__Group_6__0__Impl rule__SinglePlayerGame__Group_6__1
            {
            pushFollow(FOLLOW_14);
            rule__SinglePlayerGame__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_6__0"


    // $ANTLR start "rule__SinglePlayerGame__Group_6__0__Impl"
    // InternalDsl.g:2121:1: rule__SinglePlayerGame__Group_6__0__Impl : ( 'releaseDate' ) ;
    public final void rule__SinglePlayerGame__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2125:1: ( ( 'releaseDate' ) )
            // InternalDsl.g:2126:1: ( 'releaseDate' )
            {
            // InternalDsl.g:2126:1: ( 'releaseDate' )
            // InternalDsl.g:2127:2: 'releaseDate'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getReleaseDateKeyword_6_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getReleaseDateKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_6__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_6__1"
    // InternalDsl.g:2136:1: rule__SinglePlayerGame__Group_6__1 : rule__SinglePlayerGame__Group_6__1__Impl ;
    public final void rule__SinglePlayerGame__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2140:1: ( rule__SinglePlayerGame__Group_6__1__Impl )
            // InternalDsl.g:2141:2: rule__SinglePlayerGame__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_6__1"


    // $ANTLR start "rule__SinglePlayerGame__Group_6__1__Impl"
    // InternalDsl.g:2147:1: rule__SinglePlayerGame__Group_6__1__Impl : ( ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 ) ) ;
    public final void rule__SinglePlayerGame__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2151:1: ( ( ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 ) ) )
            // InternalDsl.g:2152:1: ( ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 ) )
            {
            // InternalDsl.g:2152:1: ( ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 ) )
            // InternalDsl.g:2153:2: ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getReleaseDateAssignment_6_1()); 
            // InternalDsl.g:2154:2: ( rule__SinglePlayerGame__ReleaseDateAssignment_6_1 )
            // InternalDsl.g:2154:3: rule__SinglePlayerGame__ReleaseDateAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__ReleaseDateAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getReleaseDateAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_6__1__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_7__0"
    // InternalDsl.g:2163:1: rule__SinglePlayerGame__Group_7__0 : rule__SinglePlayerGame__Group_7__0__Impl rule__SinglePlayerGame__Group_7__1 ;
    public final void rule__SinglePlayerGame__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2167:1: ( rule__SinglePlayerGame__Group_7__0__Impl rule__SinglePlayerGame__Group_7__1 )
            // InternalDsl.g:2168:2: rule__SinglePlayerGame__Group_7__0__Impl rule__SinglePlayerGame__Group_7__1
            {
            pushFollow(FOLLOW_13);
            rule__SinglePlayerGame__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_7__0"


    // $ANTLR start "rule__SinglePlayerGame__Group_7__0__Impl"
    // InternalDsl.g:2175:1: rule__SinglePlayerGame__Group_7__0__Impl : ( 'difficultyLevels' ) ;
    public final void rule__SinglePlayerGame__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2179:1: ( ( 'difficultyLevels' ) )
            // InternalDsl.g:2180:1: ( 'difficultyLevels' )
            {
            // InternalDsl.g:2180:1: ( 'difficultyLevels' )
            // InternalDsl.g:2181:2: 'difficultyLevels'
            {
             before(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsKeyword_7_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_7__0__Impl"


    // $ANTLR start "rule__SinglePlayerGame__Group_7__1"
    // InternalDsl.g:2190:1: rule__SinglePlayerGame__Group_7__1 : rule__SinglePlayerGame__Group_7__1__Impl ;
    public final void rule__SinglePlayerGame__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2194:1: ( rule__SinglePlayerGame__Group_7__1__Impl )
            // InternalDsl.g:2195:2: rule__SinglePlayerGame__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_7__1"


    // $ANTLR start "rule__SinglePlayerGame__Group_7__1__Impl"
    // InternalDsl.g:2201:1: rule__SinglePlayerGame__Group_7__1__Impl : ( ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 ) ) ;
    public final void rule__SinglePlayerGame__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2205:1: ( ( ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 ) ) )
            // InternalDsl.g:2206:1: ( ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 ) )
            {
            // InternalDsl.g:2206:1: ( ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 ) )
            // InternalDsl.g:2207:2: ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 )
            {
             before(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsAssignment_7_1()); 
            // InternalDsl.g:2208:2: ( rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 )
            // InternalDsl.g:2208:3: rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__Group_7__1__Impl"


    // $ANTLR start "rule__GamingPlatform__GamesAssignment_3_2"
    // InternalDsl.g:2217:1: rule__GamingPlatform__GamesAssignment_3_2 : ( ruleGame ) ;
    public final void rule__GamingPlatform__GamesAssignment_3_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2221:1: ( ( ruleGame ) )
            // InternalDsl.g:2222:2: ( ruleGame )
            {
            // InternalDsl.g:2222:2: ( ruleGame )
            // InternalDsl.g:2223:3: ruleGame
            {
             before(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_2_0()); 
            pushFollow(FOLLOW_2);
            ruleGame();

            state._fsp--;

             after(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__GamesAssignment_3_2"


    // $ANTLR start "rule__GamingPlatform__GamesAssignment_3_3_1"
    // InternalDsl.g:2232:1: rule__GamingPlatform__GamesAssignment_3_3_1 : ( ruleGame ) ;
    public final void rule__GamingPlatform__GamesAssignment_3_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2236:1: ( ( ruleGame ) )
            // InternalDsl.g:2237:2: ( ruleGame )
            {
            // InternalDsl.g:2237:2: ( ruleGame )
            // InternalDsl.g:2238:3: ruleGame
            {
             before(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleGame();

            state._fsp--;

             after(grammarAccess.getGamingPlatformAccess().getGamesGameParserRuleCall_3_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GamingPlatform__GamesAssignment_3_3_1"


    // $ANTLR start "rule__MultiplayerGame__TitleAssignment_3_1"
    // InternalDsl.g:2247:1: rule__MultiplayerGame__TitleAssignment_3_1 : ( ruleEString ) ;
    public final void rule__MultiplayerGame__TitleAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2251:1: ( ( ruleEString ) )
            // InternalDsl.g:2252:2: ( ruleEString )
            {
            // InternalDsl.g:2252:2: ( ruleEString )
            // InternalDsl.g:2253:3: ruleEString
            {
             before(grammarAccess.getMultiplayerGameAccess().getTitleEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameAccess().getTitleEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__TitleAssignment_3_1"


    // $ANTLR start "rule__MultiplayerGame__GenreAssignment_4_1"
    // InternalDsl.g:2262:1: rule__MultiplayerGame__GenreAssignment_4_1 : ( ruleEString ) ;
    public final void rule__MultiplayerGame__GenreAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2266:1: ( ( ruleEString ) )
            // InternalDsl.g:2267:2: ( ruleEString )
            {
            // InternalDsl.g:2267:2: ( ruleEString )
            // InternalDsl.g:2268:3: ruleEString
            {
             before(grammarAccess.getMultiplayerGameAccess().getGenreEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameAccess().getGenreEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__GenreAssignment_4_1"


    // $ANTLR start "rule__MultiplayerGame__RatingAssignment_5_1"
    // InternalDsl.g:2277:1: rule__MultiplayerGame__RatingAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__MultiplayerGame__RatingAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2281:1: ( ( ruleEInt ) )
            // InternalDsl.g:2282:2: ( ruleEInt )
            {
            // InternalDsl.g:2282:2: ( ruleEInt )
            // InternalDsl.g:2283:3: ruleEInt
            {
             before(grammarAccess.getMultiplayerGameAccess().getRatingEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameAccess().getRatingEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__RatingAssignment_5_1"


    // $ANTLR start "rule__MultiplayerGame__ReleaseDateAssignment_6_1"
    // InternalDsl.g:2292:1: rule__MultiplayerGame__ReleaseDateAssignment_6_1 : ( ruleEDate ) ;
    public final void rule__MultiplayerGame__ReleaseDateAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2296:1: ( ( ruleEDate ) )
            // InternalDsl.g:2297:2: ( ruleEDate )
            {
            // InternalDsl.g:2297:2: ( ruleEDate )
            // InternalDsl.g:2298:3: ruleEDate
            {
             before(grammarAccess.getMultiplayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__ReleaseDateAssignment_6_1"


    // $ANTLR start "rule__MultiplayerGame__MaxPlayersAssignment_7_1"
    // InternalDsl.g:2307:1: rule__MultiplayerGame__MaxPlayersAssignment_7_1 : ( ruleEInt ) ;
    public final void rule__MultiplayerGame__MaxPlayersAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2311:1: ( ( ruleEInt ) )
            // InternalDsl.g:2312:2: ( ruleEInt )
            {
            // InternalDsl.g:2312:2: ( ruleEInt )
            // InternalDsl.g:2313:3: ruleEInt
            {
             before(grammarAccess.getMultiplayerGameAccess().getMaxPlayersEIntParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getMultiplayerGameAccess().getMaxPlayersEIntParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__MultiplayerGame__MaxPlayersAssignment_7_1"


    // $ANTLR start "rule__TournamentGame__TitleAssignment_3_1"
    // InternalDsl.g:2322:1: rule__TournamentGame__TitleAssignment_3_1 : ( ruleEString ) ;
    public final void rule__TournamentGame__TitleAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2326:1: ( ( ruleEString ) )
            // InternalDsl.g:2327:2: ( ruleEString )
            {
            // InternalDsl.g:2327:2: ( ruleEString )
            // InternalDsl.g:2328:3: ruleEString
            {
             before(grammarAccess.getTournamentGameAccess().getTitleEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTournamentGameAccess().getTitleEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__TitleAssignment_3_1"


    // $ANTLR start "rule__TournamentGame__GenreAssignment_4_1"
    // InternalDsl.g:2337:1: rule__TournamentGame__GenreAssignment_4_1 : ( ruleEString ) ;
    public final void rule__TournamentGame__GenreAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2341:1: ( ( ruleEString ) )
            // InternalDsl.g:2342:2: ( ruleEString )
            {
            // InternalDsl.g:2342:2: ( ruleEString )
            // InternalDsl.g:2343:3: ruleEString
            {
             before(grammarAccess.getTournamentGameAccess().getGenreEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTournamentGameAccess().getGenreEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__GenreAssignment_4_1"


    // $ANTLR start "rule__TournamentGame__RatingAssignment_5_1"
    // InternalDsl.g:2352:1: rule__TournamentGame__RatingAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__TournamentGame__RatingAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2356:1: ( ( ruleEInt ) )
            // InternalDsl.g:2357:2: ( ruleEInt )
            {
            // InternalDsl.g:2357:2: ( ruleEInt )
            // InternalDsl.g:2358:3: ruleEInt
            {
             before(grammarAccess.getTournamentGameAccess().getRatingEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getTournamentGameAccess().getRatingEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__RatingAssignment_5_1"


    // $ANTLR start "rule__TournamentGame__ReleaseDateAssignment_6_1"
    // InternalDsl.g:2367:1: rule__TournamentGame__ReleaseDateAssignment_6_1 : ( ruleEDate ) ;
    public final void rule__TournamentGame__ReleaseDateAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2371:1: ( ( ruleEDate ) )
            // InternalDsl.g:2372:2: ( ruleEDate )
            {
            // InternalDsl.g:2372:2: ( ruleEDate )
            // InternalDsl.g:2373:3: ruleEDate
            {
             before(grammarAccess.getTournamentGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getTournamentGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__ReleaseDateAssignment_6_1"


    // $ANTLR start "rule__TournamentGame__TournamentFormatAssignment_7_1"
    // InternalDsl.g:2382:1: rule__TournamentGame__TournamentFormatAssignment_7_1 : ( ruleEString ) ;
    public final void rule__TournamentGame__TournamentFormatAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2386:1: ( ( ruleEString ) )
            // InternalDsl.g:2387:2: ( ruleEString )
            {
            // InternalDsl.g:2387:2: ( ruleEString )
            // InternalDsl.g:2388:3: ruleEString
            {
             before(grammarAccess.getTournamentGameAccess().getTournamentFormatEStringParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTournamentGameAccess().getTournamentFormatEStringParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__TournamentGame__TournamentFormatAssignment_7_1"


    // $ANTLR start "rule__SinglePlayerGame__TitleAssignment_3_1"
    // InternalDsl.g:2397:1: rule__SinglePlayerGame__TitleAssignment_3_1 : ( ruleEString ) ;
    public final void rule__SinglePlayerGame__TitleAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2401:1: ( ( ruleEString ) )
            // InternalDsl.g:2402:2: ( ruleEString )
            {
            // InternalDsl.g:2402:2: ( ruleEString )
            // InternalDsl.g:2403:3: ruleEString
            {
             before(grammarAccess.getSinglePlayerGameAccess().getTitleEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameAccess().getTitleEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__TitleAssignment_3_1"


    // $ANTLR start "rule__SinglePlayerGame__GenreAssignment_4_1"
    // InternalDsl.g:2412:1: rule__SinglePlayerGame__GenreAssignment_4_1 : ( ruleEString ) ;
    public final void rule__SinglePlayerGame__GenreAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2416:1: ( ( ruleEString ) )
            // InternalDsl.g:2417:2: ( ruleEString )
            {
            // InternalDsl.g:2417:2: ( ruleEString )
            // InternalDsl.g:2418:3: ruleEString
            {
             before(grammarAccess.getSinglePlayerGameAccess().getGenreEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameAccess().getGenreEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__GenreAssignment_4_1"


    // $ANTLR start "rule__SinglePlayerGame__RatingAssignment_5_1"
    // InternalDsl.g:2427:1: rule__SinglePlayerGame__RatingAssignment_5_1 : ( ruleEInt ) ;
    public final void rule__SinglePlayerGame__RatingAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2431:1: ( ( ruleEInt ) )
            // InternalDsl.g:2432:2: ( ruleEInt )
            {
            // InternalDsl.g:2432:2: ( ruleEInt )
            // InternalDsl.g:2433:3: ruleEInt
            {
             before(grammarAccess.getSinglePlayerGameAccess().getRatingEIntParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameAccess().getRatingEIntParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__RatingAssignment_5_1"


    // $ANTLR start "rule__SinglePlayerGame__ReleaseDateAssignment_6_1"
    // InternalDsl.g:2442:1: rule__SinglePlayerGame__ReleaseDateAssignment_6_1 : ( ruleEDate ) ;
    public final void rule__SinglePlayerGame__ReleaseDateAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2446:1: ( ( ruleEDate ) )
            // InternalDsl.g:2447:2: ( ruleEDate )
            {
            // InternalDsl.g:2447:2: ( ruleEDate )
            // InternalDsl.g:2448:3: ruleEDate
            {
             before(grammarAccess.getSinglePlayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameAccess().getReleaseDateEDateParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__ReleaseDateAssignment_6_1"


    // $ANTLR start "rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1"
    // InternalDsl.g:2457:1: rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1 : ( ruleEInt ) ;
    public final void rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:2461:1: ( ( ruleEInt ) )
            // InternalDsl.g:2462:2: ( ruleEInt )
            {
            // InternalDsl.g:2462:2: ( ruleEInt )
            // InternalDsl.g:2463:3: ruleEInt
            {
             before(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsEIntParserRuleCall_7_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getSinglePlayerGameAccess().getDifficultyLevelsEIntParserRuleCall_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SinglePlayerGame__DifficultyLevelsAssignment_7_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000005040000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000014000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000F84000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000020040L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002784000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000008784000L});

}